import 'dotenv/config';
import * as promClient from 'prom-client';

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
import cors from 'cors';
import express, { RequestHandler } from 'express';
import promBundle from 'express-prom-bundle';
import {
  VOLUME_CHECKPOINT_DURATION_SEC,
  DATABASE_CHECKPOINT_DURATION_SEC,
  ONE_DAY_SEC,
  ONE_HOUR_SEC,
  PORT,
} from './stats_utils/constants';
import { CompleteFillsQueryOptions } from './stats_utils/types';
import { ManifestStatsServer } from './stats_utils/manifestStatsServer';
import { TvlMonitor } from './stats_utils/tvlMonitor';
import {
  isValidSolanaSignature,
  parseBoundedQueryInteger,
  positiveIntFromEnv,
} from './stats_utils/httpValidation';
import { createExpensiveQueryAdmission } from './stats_utils/httpAdmission';

// Global error handlers to catch unhandled errors and log them before exit
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  console.error('Stack:', reason instanceof Error ? reason.stack : 'No stack');
});

process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  console.error('Stack:', error.stack);
  // Give time for logs to flush before exit
  setTimeout(() => process.exit(1), 1000);
});

const { READ_ONLY } = process.env;

const IS_READ_ONLY = READ_ONLY === 'true';
if (IS_READ_ONLY) {
  console.log('⚠️  Running in READ-ONLY mode - database writes are disabled');
}

const fills: promClient.Counter<'market'> = new promClient.Counter({
  name: 'fills',
  help: 'Number of fills',
  labelNames: ['market'] as const,
});

const reconnects: promClient.Counter<string> = new promClient.Counter({
  name: 'reconnects',
  help: 'Number of reconnects to websocket',
});

const volume: promClient.Gauge<'market' | 'mint' | 'side'> =
  new promClient.Gauge({
    name: 'volume',
    help: 'Volume in last 24 hours in tokens',
    labelNames: ['market', 'mint', 'side'] as const,
  });

const lastPrice: promClient.Gauge<'market'> = new promClient.Gauge({
  name: 'last_price',
  help: 'Last traded price',
  labelNames: ['market'] as const,
});

const depth: promClient.Gauge<'depth_bps' | 'market' | 'trader'> =
  new promClient.Gauge({
    name: 'depth',
    help: 'Notional in orders at a given depth by trader',
    labelNames: ['depth_bps', 'market', 'trader'] as const,
  });

// Cumulative since process start, SOL- and USDC-quote markets only (the
// `quote` label is the denomination). Fills with no detected source land in
// the 'none' bucket so per-source series sum to total volume.
const aggregatorQuoteVolume: promClient.Counter<'aggregator' | 'quote'> =
  new promClient.Counter({
    name: 'aggregator_quote_volume',
    help: 'Cumulative quote volume in atoms by aggregator',
    labelNames: ['aggregator', 'quote'] as const,
  });

const originatingProtocolQuoteVolume: promClient.Counter<'protocol' | 'quote'> =
  new promClient.Counter({
    name: 'originating_protocol_quote_volume',
    help: 'Cumulative quote volume in atoms by originating protocol',
    labelNames: ['protocol', 'quote'] as const,
  });

const dbQueryCount: promClient.Counter<'query_type' | 'status'> =
  new promClient.Counter({
    name: 'db_query_count',
    help: 'Number of database queries executed',
    labelNames: ['query_type', 'status'] as const,
  });

const dbQueryDuration: promClient.Histogram<'query_type'> =
  new promClient.Histogram({
    name: 'db_query_duration_seconds',
    help: 'Duration of database queries in seconds',
    labelNames: ['query_type'] as const,
    buckets: [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 2, 5],
  });

/**
 * Server for serving stats according to this spec:
 * https://docs.google.com/document/d/1v27QFoQq1SKT3Priq3aqPgB70Xd_PnDzbOCiuoCyixw/edit?tab=t.0
 */
const run = async () => {
  // Validate environment variables
  const { RPC_URL, DATABASE_URL } = process.env;

  if (!RPC_URL) {
    throw new Error('RPC_URL missing from env');
  }

  if (!DATABASE_URL && !IS_READ_ONLY) {
    console.warn(
      'WARNING: DATABASE_URL not found in environment. Data persistence will not work!',
    );
  }

  // Set up Prometheus metrics
  promClient.collectDefaultMetrics({
    labels: {
      app: 'stats',
    },
  });

  const register = new promClient.Registry();
  register.setDefaultLabels({
    app: 'stats',
  });
  const metricsApp = express();

  // Find available port starting from 9090
  const findAvailablePort = async (startPort: number): Promise<number> => {
    const maxAttempts = 10;
    for (let i = 0; i < maxAttempts; i++) {
      const port = startPort + i;
      try {
        await new Promise<void>((resolve, reject) => {
          const server = metricsApp
            .listen(port, () => {
              server.close();
              resolve();
            })
            .on('error', reject);
        });
        return port;
      } catch (error: any) {
        if (error.code !== 'EADDRINUSE') {
          throw error;
        }
        // Port is in use, try next one
      }
    }
    throw new Error(
      `Could not find available port after ${maxAttempts} attempts starting from ${startPort}`,
    );
  };

  const metricsPort = await findAvailablePort(9090);
  metricsApp.listen(metricsPort, () => {
    console.log(`Prometheus metrics server listening on port ${metricsPort}`);
  });

  const promMetrics = promBundle({
    includeMethod: true,
    metricsApp,
    autoregister: false,
  });
  metricsApp.use(promMetrics);

  // Initialize the stats server
  const statsServer: ManifestStatsServer = new ManifestStatsServer(
    RPC_URL,
    IS_READ_ONLY,
    DATABASE_URL,
    {
      fills,
      reconnects,
      volume,
      lastPrice,
      depth,
      aggregatorQuoteVolume,
      originatingProtocolQuoteVolume,
      dbQueryCount,
      dbQueryDuration,
    },
  );

  try {
    await statsServer.initialize();
  } catch (error) {
    console.error('Error initializing server:', error);
    throw error;
  }

  // Initialize TVL monitor for hourly alerts
  const { Connection } = await import('@solana/web3.js');
  const tvlMonitor = new TvlMonitor(
    new Connection(RPC_URL),
    process.env.TVL_DISCORD_WEBHOOK_URL,
  );

  // Set up Express routes
  /**
   * GET /tickers preserves the existing per-market response and fields.
   * CoinGecko can opt in with GET /tickers?aggregate=true after deployment;
   * omitted or other aggregate values keep the per-market view.
   *
   * Aggregation groups by ordered base/quote mint pair and sums 24h base and
   * quote volumes in token units. The market with the highest individual 24h
   * quote volume supplies ticker_id, pool_id, last_price, bid/ask, and trade_url;
   * equal volumes use the lexicographically smallest market address. Different
   * quote tokens and reversed pairs stay separate. Market IDs remain valid for
   * the unchanged /orderbook endpoint.
   *
   * Both views use the same checkpoint snapshot, refreshed about every 5 min.
   */
  const tickersHandler: RequestHandler = (req, res) => {
    // Serve the pre-serialized cache verbatim. Use type().send(string) rather
    // than send(object) so Express doesn't re-stringify it.
    res
      .type('application/json')
      .send(statsServer.getTickersJson(req.query.aggregate === 'true'));
  };
  const metadataHandler: RequestHandler = (_req, res) => {
    res.send(JSON.stringify(Object.fromEntries(statsServer.getMetadata())));
  };
  const orderbookHandler: RequestHandler = async (req, res) => {
    try {
      const depth = parseBoundedQueryInteger(
        req.query.depth,
        100,
        1,
        500,
        'depth',
      );
      res.send(
        await statsServer.getOrderbook(req.query.ticker_id as string, depth),
      );
    } catch (error) {
      res.status(400).send({ error: (error as Error).message });
    }
  };
  const volumeHandler: RequestHandler = (_req, res) => {
    res.type('application/json').send(statsServer.getVolumeJson());
  };
  const feesHandler: RequestHandler = async (req, res) => {
    try {
      const { startTimestamp, endTimestamp } = req.query;
      if (
        typeof startTimestamp !== 'string' ||
        !/^\d+$/.test(startTimestamp) ||
        typeof endTimestamp !== 'string' ||
        !/^\d+$/.test(endTimestamp)
      ) {
        res
          .status(400)
          .json({
            error: 'startTimestamp and endTimestamp are required Unix seconds',
          });
        return;
      }
      res.json(
        await statsServer.feeCollections.query(
          Number(startTimestamp),
          Number(endTimestamp),
        ),
      );
    } catch (error) {
      if (error instanceof RangeError) {
        res.status(400).json({ error: error.message });
      } else {
        console.error('Fee reporting unavailable:', error);
        res.setHeader('Retry-After', String(ONE_HOUR_SEC));
        res
          .status(503)
          .json({
            error:
              'Requested fee interval is not fully indexed or reporting is unavailable',
          });
      }
    }
  };
  const tradersHandler: RequestHandler = (req, res) => {
    try {
      const includeDebug = req.query.debug === 'true';
      const limit = parseBoundedQueryInteger(
        req.query.limit,
        500,
        1,
        1_000,
        'limit',
      );
      res.send(statsServer.getTraders(includeDebug, limit));
    } catch (error) {
      if (error instanceof RangeError) {
        res.status(400).send({ error: error.message });
        return;
      }
      throw error;
    }
  };
  const recentFillsHandler: RequestHandler = (req, res) => {
    res.send(statsServer.getRecentFills(req.query.market as string));
  };
  // Pagination bounds for /completeFills. #663 capped these at 500/10_000,
  // which put a hard ceiling of limit+offset rows on any filter: callers
  // paginating a busy market hit offset 10_000 with a still-full page and had
  // no way to reach the rest, so the endpoint silently stopped returning
  // complete data. Restore the depth the endpoint had before that change.
  //
  // Neither is capped, matching the behaviour before #663. A 1000 ceiling was
  // tried first and was still too low for real callers: manifest-app's
  // destinyCalculations requests limit=10000, and OrderFlowAnalysis passes the
  // number of fills already loaded, which grows without bound. Both were 400ing
  // on every call.
  //
  // The tradeoff is explicit: limit bounds the size of one response, so an
  // unbounded value lets a single request ask the server to materialize a very
  // large result. At the measured 665 bytes/fill a 10k page is ~6.4MB, which is
  // fine, but nothing stops a caller asking for far more. The durable fix is
  // cursor pagination over (slot, id) plus clients that page instead of asking
  // for everything at once.
  const MAX_COMPLETE_FILLS_LIMIT = Number.MAX_SAFE_INTEGER;
  const MAX_COMPLETE_FILLS_OFFSET = Number.MAX_SAFE_INTEGER;

  const completeFillsHandler: RequestHandler = async (req, res) => {
    try {
      const options: CompleteFillsQueryOptions = {
        market: req.query.market as string,
        taker: req.query.taker as string,
        maker: req.query.maker as string,
        wallet: req.query.wallet as string,
        signature: req.query.signature as string,
        limit: parseBoundedQueryInteger(
          req.query.limit,
          100,
          1,
          MAX_COMPLETE_FILLS_LIMIT,
          'limit',
        ),
        offset: parseBoundedQueryInteger(
          req.query.offset,
          0,
          0,
          MAX_COMPLETE_FILLS_OFFSET,
          'offset',
        ),
        fromSlot:
          req.query.fromSlot === undefined
            ? undefined
            : parseBoundedQueryInteger(
                req.query.fromSlot,
                0,
                0,
                Number.MAX_SAFE_INTEGER,
                'fromSlot',
              ),
        toSlot:
          req.query.toSlot === undefined
            ? undefined
            : parseBoundedQueryInteger(
                req.query.toSlot,
                0,
                0,
                Number.MAX_SAFE_INTEGER,
                'toSlot',
              ),
      };

      const result = await statsServer.getCompleteFillsFromDatabase(options);
      res.send(result);
    } catch (error) {
      // A RangeError here is a malformed client query, not a server fault.
      // Log it as a single line instead of a stack trace: these arrive in
      // tight retry loops and previously crowded real errors out of the log.
      if (error instanceof RangeError) {
        console.warn('Rejected completeFills query:', error.message);
        res.status(400).send({ error: error.message });
        return;
      }
      console.error('Error in completeFills handler:', error);
      res.status(500).send({ error: 'Internal server error' });
    }
  };
  const altsHandler: RequestHandler = async (_req, res) => {
    res.send(await statsServer.getAlts());
  };
  const notionalHandler: RequestHandler = (_req, res) => {
    res.type('application/json').send(statsServer.getNotionalJson());
  };
  const checkpointsHandler: RequestHandler = (_req, res) => {
    res.type('application/json').send(statsServer.getCheckpointsJson());
  };
  const checkpointStatusHandler: RequestHandler = (_req, res) => {
    res.send(statsServer.getCheckpointStatus());
  };

  // Backfills trigger expensive RPC/database work. A small in-process queue
  // keeps the endpoint from being used for resource abuse.
  const activeBackfills = new Set<string>();
  const backfillHandler: RequestHandler = async (req, res) => {
    // Accept the signature either as a query param (GET) or a JSON body (POST).
    const signature: unknown = req.query.signature ?? req.body?.signature;
    if (!isValidSolanaSignature(signature)) {
      res.status(400).send({ error: 'A valid signature is required' });
      return;
    }
    if (activeBackfills.has(signature)) {
      res.status(409).send({ error: 'Backfill already in progress' });
      return;
    }
    if (activeBackfills.size >= 2) {
      res.status(429).send({ error: 'Backfill queue is full' });
      return;
    }
    activeBackfills.add(signature);
    try {
      const result = await statsServer.backfillTransaction(signature);
      res.send({
        success: true,
        signature,
        backfilled: result.backfilled,
        alreadyExisted: result.alreadyExisted,
      });
    } catch (error) {
      console.error('Error in backfill handler:', error);
      res.status(500).send({ error: 'Internal server error' });
    } finally {
      activeBackfills.delete(signature);
    }
  };

  const wrapperHandler: RequestHandler = (req, res) => {
    const owner = req.query.owner as string;
    if (!owner) {
      res.status(400).send({ error: 'owner parameter is required' });
      return;
    }

    const wrapper = statsServer.getWrapper(owner);
    if (wrapper) {
      res.send({ owner, wrapper });
    } else {
      res.status(404).send({ error: 'No wrapper found for owner', owner });
    }
  };

  const wrappersHandler: RequestHandler = (_req, res) => {
    res.type('application/json').send(statsServer.getAllWrappersJson());
  };

  const app = express();
  // Fly terminates TLS and proxies to us, so the socket peer is always the
  // proxy. Trust exactly one hop: Fly appends the real client to
  // X-Forwarded-For, so the last entry is the only one it vouches for.
  // 'true' would take the leftmost entry instead, which is whatever the caller
  // put in the header - spoofable, and wrong for clients behind their own
  // proxy. req.ip is used for logging only now that the per-minute cap is off.
  app.set('trust proxy', 1);
  // No per-minute request cap. The 30/minute cap was shared across
  // /completeFills, /alts and /events, and our own bots page through
  // /completeFills far faster than that - they spent the budget legitimately
  // and then 429d themselves off the API.
  //
  // What remains is a concurrency ceiling, sized to serve load rather than to
  // ration it: 32 in flight against a 40-connection pool, leaving headroom for
  // fill ingestion, which shares the pool and must not be starved by reads.
  // Over the ceiling, requests queue (and are paced) instead of failing; a
  // request only fails once the queue is 1024 deep or it has waited 15s, which
  // leaves it time to run before the 30s request timeout below. Both knobs are
  // env-tunable so capacity can be raised without a deploy of this file, and
  // STATS_DB_POOL_MAX should move with them.
  const expensiveQueryAdmission = createExpensiveQueryAdmission({
    maxConcurrent: positiveIntFromEnv('STATS_MAX_CONCURRENT_QUERIES', 32),
    maxQueued: positiveIntFromEnv('STATS_MAX_QUEUED_QUERIES', 1024),
    maxQueueWaitMs: 15_000,
  });
  app.use(express.json({ limit: '4kb' }));
  app.use(cors());

  // HTTP request metrics middleware - tracks latency and status codes per endpoint
  // Use a separate registry to avoid metric name collisions with the metricsApp promBundle
  const httpApiRegistry = new promClient.Registry();
  const httpMetrics = promBundle({
    includeMethod: true,
    includePath: true,
    includeStatusCode: true,
    promRegistry: httpApiRegistry,
    metricsPath: '/metrics', // Expose on main app too for convenience
    normalizePath: [
      // Normalize paths with query params to avoid cardinality explosion
      ['^/orderbook.*', '/orderbook'],
      ['^/wrapper.*', '/wrapper'],
      ['^/backfill.*', '/backfill'],
      ['^/completeFills.*', '/completeFills'],
      ['^/recentFills.*', '/recentFills'],
      ['^/traders.*', '/traders'],
    ],
  });
  app.use(httpMetrics);

  // Global timeout middleware - 30 second timeout for all requests
  app.use((req, res, next) => {
    res.setTimeout(30_000, () => {
      console.error(`Request timeout: ${req.method} ${req.path} ${req.query}`);
      if (!res.headersSent) {
        res.status(503).send({ error: 'Request timeout' });
      }
    });
    next();
  });

  app.get('/tickers', tickersHandler);
  app.get('/metadata', metadataHandler);
  app.get('/orderbook', orderbookHandler);
  app.get('/volume', volumeHandler);
  app.get('/fees', feesHandler);
  app.get('/traders', tradersHandler);
  app.get('/traders/debug', (req, res) => {
    const requestedLimit =
      req.query.limit === undefined ? 500 : Number(req.query.limit);
    if (
      !Number.isSafeInteger(requestedLimit) ||
      requestedLimit < 1 ||
      requestedLimit > 1_000
    ) {
      res
        .status(400)
        .send({ error: 'limit must be an integer between 1 and 1000' });
      return;
    }
    const limit = requestedLimit;
    res.send(statsServer.getTraders(true, limit));
  });
  app.get('/recentFills', recentFillsHandler);
  app.get('/completeFills', expensiveQueryAdmission, completeFillsHandler);
  app.get('/alts', expensiveQueryAdmission, altsHandler);
  app.get('/notional', notionalHandler);
  app.get('/checkpoints', checkpointsHandler);
  app.get('/checkpointStatus', checkpointStatusHandler);
  app.get('/backfill', backfillHandler);
  app.post('/backfill', backfillHandler);
  app.get('/wrapper', wrapperHandler);
  app.get('/wrappers', wrappersHandler);

  // GeckoTerminal integration endpoints
  app.get('/latest-block', (_req, res) => {
    res.send(statsServer.getGeckoLatestBlock());
  });

  app.get('/asset', (req, res) => {
    const id = req.query.id as string;
    if (!id) {
      res.status(400).send({ error: 'id parameter is required' });
      return;
    }
    const asset = statsServer.getGeckoAsset(id);
    if (!asset) {
      res.status(404).send({ error: 'Asset not found', id });
      return;
    }
    res.send(asset);
  });

  app.get('/pair', (req, res) => {
    const id = req.query.id as string;
    if (!id) {
      res.status(400).send({ error: 'id parameter is required' });
      return;
    }
    const pair = statsServer.getGeckoPair(id);
    if (!pair) {
      res.status(404).send({ error: 'Pair not found', id });
      return;
    }
    res.send(pair);
  });

  app.get('/events', expensiveQueryAdmission, (req, res) => {
    const fromBlock = parseInt(req.query.fromBlock as string);
    const toBlock = parseInt(req.query.toBlock as string);
    if (isNaN(fromBlock) || isNaN(toBlock)) {
      res
        .status(400)
        .send({ error: 'fromBlock and toBlock parameters are required' });
      return;
    }
    if (fromBlock < 0 || toBlock < fromBlock || toBlock - fromBlock > 10_000) {
      res.status(400).send({
        error: 'block range must be ordered, non-negative, and at most 10000',
      });
      return;
    }
    try {
      res.send(statsServer.getGeckoEvents(fromBlock, toBlock, 5_000));
    } catch (error) {
      if (error instanceof RangeError) {
        res.status(413).send({ error: error.message });
        return;
      }
      throw error;
    }
  });

  // Add health check endpoint for Fly.io
  app.get('/health', (_req, res) => {
    res.status(200).send('OK');
  });

  app.listen(Number(PORT!), () => {
    console.log(`Server running on port ${PORT}`);
  });

  // Set up graceful shutdown
  const gracefulShutdown = async (signal: string) => {
    console.log(`Received ${signal}, saving state before exit...`);
    try {
      if (DATABASE_URL && !IS_READ_ONLY) {
        await statsServer.saveState();
      }
      await statsServer.shutdown();
      console.log('State saved, exiting');
      process.exit(0);
    } catch (error) {
      console.error('Error during shutdown:', error);
      process.exit(1);
    }
  };

  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

  await Promise.all([
    // Index collector SOL balance increases at startup and hourly, keeping
    // seven days of in-memory hourly totals for the /fees endpoint.
    (async () => {
      while (true) {
        try {
          await statsServer.feeCollections.poll();
        } catch (error) {
          console.error(
            'Fee collection indexing failed; coverage has not advanced:',
            error,
          );
        }
        await sleep(ONE_HOUR_SEC * 1_000);
      }
    })(),
    // Isolate advancing checkpoints so that it is more reliable. The most
    // important feature of stats server is accurate volume reporting, so dont
    // let the database cause issues with live serving of volume.
    (async () => {
      // eslint-disable-next-line no-constant-condition
      while (true) {
        try {
          await Promise.all([
            statsServer.advanceCheckpoints(),
            sleep(VOLUME_CHECKPOINT_DURATION_SEC * 1_000),
          ]);
        } catch (error) {
          console.error('Error in advancing checkpoints:', error);
          // Continue the loop instead of crashing
          await sleep(5_000); // Add a short delay before retrying
        }
      }
    })(),
    (async () => {
      // eslint-disable-next-line no-constant-condition
      while (true) {
        try {
          await Promise.all([
            sleep(DATABASE_CHECKPOINT_DURATION_SEC * 1_000),
            statsServer.depthProbe(),
            DATABASE_URL && !IS_READ_ONLY
              ? statsServer.saveState()
              : Promise.resolve(),
          ]);
        } catch (error) {
          console.error('Error in saving loop:', error);
          // Continue the loop instead of crashing
          await sleep(5_000); // Add a short delay before retrying
        }
      }
    })(),
    (async () => {
      // eslint-disable-next-line no-constant-condition
      while (true) {
        try {
          await sleep(ONE_DAY_SEC * 1_000);
          await statsServer.loadWrapperCache();
        } catch (error) {
          console.error('Error refreshing wrapper cache:', error);
          await sleep(5_000);
        }
      }
    })(),
    // Hourly TVL monitoring - alerts when TVL changes by more than 10%
    (async () => {
      // eslint-disable-next-line no-constant-condition
      while (true) {
        let retryDelayMs: number = ONE_HOUR_SEC * 1_000;
        try {
          const hasComparableBaseline: boolean =
            await tvlMonitor.checkAndAlert();
          if (!hasComparableBaseline) {
            retryDelayMs = 5_000;
          }
        } catch (error) {
          console.error('Error in TVL monitoring:', error);
          retryDelayMs = 5_000;
        }
        await sleep(retryDelayMs);
      }
    })(),
    // Hourly volume monitoring - alerts on 25% volume changes and large fills
    (async () => {
      // eslint-disable-next-line no-constant-condition
      while (true) {
        try {
          await sleep(ONE_HOUR_SEC * 1_000);
          await statsServer.checkHourlyVolumeChange();
        } catch (error) {
          console.error('Error in hourly volume check:', error);
          await sleep(5_000);
        }
      }
    })(),
    // Hourly market maker monitoring - alerts on new market makers and large volume changes
    (async () => {
      // eslint-disable-next-line no-constant-condition
      while (true) {
        try {
          await sleep(ONE_HOUR_SEC * 1_000);
          await statsServer.checkHourlyMarketMakerChanges();
        } catch (error) {
          console.error('Error in market maker monitoring:', error);
          await sleep(5_000);
        }
      }
    })(),
  ]);
};

run().catch((e) => {
  console.error('fatal error');
  throw e;
});
