use crate::validation::{io_to_program_error, to_program_error, AccountViewExt};
use pinocchio::{account::RefMut, ProgramResult};

use borsh::{BorshDeserialize, BorshSerialize};
use pinocchio::account::AccountView;
use solana_program::pubkey::Pubkey;

use crate::{
    logs::{emit_stack, GlobalDepositLog},
    program::get_mut_dynamic_account,
    quantities::{GlobalAtoms, WrapperU64},
    state::GlobalRefMut,
    validation::{loaders::GlobalDepositContext, MintAccountInfo, Signer, TokenAccountInfo},
};

#[cfg(not(feature = "certora"))]
use crate::validation::TokenProgram;

#[cfg(not(feature = "certora"))]
use super::invoke;

#[cfg(feature = "certora")]
use {
    crate::certora::summaries::token::spl_token_2022_transfer_with_fee, early_panic::early_panic,
    solana_cvt::token::spl_token_transfer,
};

#[derive(BorshDeserialize, BorshSerialize)]
pub struct GlobalDepositParams {
    pub amount_atoms: u64,
    // No trader index hint because global account is small so there is not much
    // benefit from hinted indices, unlike the market which can get large. Also,
    // seats are not permanent like on a market due to eviction, so it is more
    // likely that a client could send a bad request. Just look it up for them.
}

impl GlobalDepositParams {
    pub fn new(amount_atoms: u64) -> Self {
        GlobalDepositParams { amount_atoms }
    }
}

pub(crate) fn process_global_deposit(
    program_id: &Pubkey,
    accounts: &[AccountView],
    data: &[u8],
) -> ProgramResult {
    let params: GlobalDepositParams =
        GlobalDepositParams::try_from_slice(data).map_err(io_to_program_error)?;
    process_global_deposit_core(program_id, accounts, params)
}

#[cfg_attr(all(feature = "certora", not(feature = "certora-test")), early_panic)]
pub(crate) fn process_global_deposit_core(
    _program_id: &Pubkey,
    accounts: &[AccountView],
    params: GlobalDepositParams,
) -> ProgramResult {
    let global_deposit_context: GlobalDepositContext = GlobalDepositContext::load(accounts)?;
    let GlobalDepositParams { amount_atoms } = params;

    // Due to transfer fees, this might not be what you expect.
    let mut deposited_amount_atoms: u64 = amount_atoms;

    let GlobalDepositContext {
        payer,
        global,
        mint,
        global_vault,
        trader_token: trader_token_account,
        token_program,
    } = global_deposit_context;

    // Do the token transfer first to determine actual received amount
    if global_vault.owner_pubkey() == spl_token_2022::id() {
        let before_vault_balance_atoms: u64 = global_vault.get_balance_atoms();
        spl_token_2022_transfer_from_trader_to_global_vault(
            &token_program,
            &trader_token_account,
            &mint,
            &global_vault,
            &payer,
            amount_atoms,
        )?;

        let after_vault_balance_atoms: u64 = global_vault.get_balance_atoms();
        deposited_amount_atoms = after_vault_balance_atoms
            .checked_sub(before_vault_balance_atoms)
            .unwrap();
    } else {
        spl_token_transfer_from_trader_to_global_vault(
            &token_program,
            &trader_token_account,
            &global_vault,
            &payer,
            amount_atoms,
        )?;
    }

    // Now deposit the actual received amount (which may be less than requested due to transfer fees)
    let global_data: &mut RefMut<[u8]> = &mut global.try_borrow_mut()?;
    let mut global_dynamic_account: GlobalRefMut = get_mut_dynamic_account(global_data);
    global_dynamic_account
        .deposit_global(payer.pubkey(), GlobalAtoms::new(deposited_amount_atoms))?;

    emit_stack(GlobalDepositLog {
        global: *global.pubkey(),
        trader: *payer.pubkey(),
        global_atoms: GlobalAtoms::new(deposited_amount_atoms),
    })?;

    Ok(())
}

/** Transfer from trader to global vault using SPL Token **/
#[cfg(not(feature = "certora"))]
fn spl_token_transfer_from_trader_to_global_vault<'a>(
    token_program: &TokenProgram<'a>,
    trader_token_account: &TokenAccountInfo<'a>,
    global_vault: &TokenAccountInfo<'a>,
    payer: &Signer<'a>,
    amount_atoms: u64,
) -> ProgramResult {
    invoke(
        &spl_token::instruction::transfer(
            token_program.pubkey(),
            trader_token_account.pubkey(),
            global_vault.pubkey(),
            payer.pubkey(),
            &[],
            amount_atoms,
        )
        .map_err(to_program_error)?,
        // source, destination, authority.
        &[
            trader_token_account.as_ref(),
            global_vault.as_ref(),
            payer.as_ref(),
        ],
    )
}

#[cfg(feature = "certora")]
/** (Summary) Transfer from trader to global vault using SPL Token **/
fn spl_token_transfer_from_trader_to_global_vault<'a>(
    _token_program: &crate::validation::TokenProgram<'a>,
    trader_token_account: &TokenAccountInfo<'a>,
    global_vault: &TokenAccountInfo<'a>,
    payer: &Signer<'a>,
    amount_atoms: u64,
) -> ProgramResult {
    spl_token_transfer(
        trader_token_account.info,
        global_vault.info,
        payer.info,
        amount_atoms,
    )
}

/** Transfer from trader to global vault using SPL Token 2022 **/
#[cfg(not(feature = "certora"))]
fn spl_token_2022_transfer_from_trader_to_global_vault<'a>(
    token_program: &TokenProgram<'a>,
    trader_token_account: &TokenAccountInfo<'a>,
    mint: &MintAccountInfo<'a>,
    global_vault: &TokenAccountInfo<'a>,
    payer: &Signer<'a>,
    amount_atoms: u64,
) -> ProgramResult {
    invoke(
        &spl_token_2022::instruction::transfer_checked(
            token_program.pubkey(),
            trader_token_account.pubkey(),
            mint.info.pubkey(),
            global_vault.pubkey(),
            payer.pubkey(),
            &[],
            amount_atoms,
            mint.mint.decimals,
        )
        .map_err(to_program_error)?,
        // source, mint, destination, authority.
        &[
            trader_token_account.as_ref(),
            mint.as_ref(),
            global_vault.as_ref(),
            payer.as_ref(),
        ],
    )
}

#[cfg(feature = "certora")]
/** (Summary) Transfer from trader to global vault using SPL Token 2022.
The mint may carry a transfer fee, so the vault can receive less than the
requested amount; the processor credits the vault balance delta. **/
fn spl_token_2022_transfer_from_trader_to_global_vault<'a>(
    _token_program: &crate::validation::TokenProgram<'a>,
    trader_token_account: &TokenAccountInfo<'a>,
    _mint: &MintAccountInfo<'a>,
    global_vault: &TokenAccountInfo<'a>,
    payer: &Signer<'a>,
    amount_atoms: u64,
) -> ProgramResult {
    spl_token_2022_transfer_with_fee(
        trader_token_account.info,
        global_vault.info,
        payer.info,
        amount_atoms,
    )
}
