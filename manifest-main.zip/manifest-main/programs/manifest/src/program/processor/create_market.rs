use crate::validation::{to_program_error, AccountViewExt};
use pinocchio::{
    account::AccountView,
    sysvars::{rent::Rent, Sysvar},
    ProgramResult,
};
use std::mem::size_of;

#[cfg(not(feature = "certora"))]
use crate::validation::get_global_address;
use crate::{
    logs::{emit_stack, CreateMarketLog},
    program::{expand_market_if_needed, invoke},
    require,
    state::MarketFixed,
    utils::create_account,
    validation::loaders::CreateMarketContext,
};
use hypertree::{get_mut_helper, trace};
use solana_program::{program_pack::Pack, pubkey::Pubkey};
use spl_token_2022_interface::{
    extension::{
        account_len::try_calculate_account_len_from_mint_data,
        mint_close_authority::MintCloseAuthority, permanent_delegate::PermanentDelegate,
        BaseStateWithExtensions, StateWithExtensions,
    },
    state::Mint,
};

pub(crate) fn process_create_market(
    _program_id: &Pubkey,
    accounts: &[AccountView],
    _data: &[u8],
) -> ProgramResult {
    trace!("process_create_market accs={}", accounts.len());
    let create_market_context: CreateMarketContext = CreateMarketContext::load(accounts)?;

    let CreateMarketContext {
        market,
        payer,
        base_mint,
        quote_mint,
        base_vault,
        quote_vault,
        base_vault_bump,
        quote_vault_bump,
        system_program,
        // Validated on load; the CPIs below name the accounts the
        // instruction names, and a program is not one of them.
        token_program: _,
        // Validated on load; the CPIs below name the accounts the
        // instruction names, and a program is not one of them.
        token_program_22: _,
    } = create_market_context;

    require!(
        base_mint.info.pubkey() != quote_mint.info.pubkey(),
        crate::program::ManifestError::InvalidMarketParameters,
        "Base and quote must be different",
    )?;

    for mint in [base_mint.as_ref(), quote_mint.as_ref()] {
        if mint.owner_pubkey() == spl_token_2022::id() {
            let mint_data: pinocchio::account::Ref<[u8]> = mint.try_borrow()?;
            let pool_mint: StateWithExtensions<'_, Mint> =
                StateWithExtensions::<Mint>::unpack(&mint_data).map_err(to_program_error)?;
            // Closable mints can be replaced with different ones, breaking some saved info on the market.
            if let Ok(extension) = pool_mint.get_extension::<MintCloseAuthority>() {
                let close_authority: Option<Pubkey> = extension.close_authority.into();
                if close_authority.is_some() {
                    solana_program::msg!(
                        "Warning, you are creating a market with a close authority."
                    );
                }
            }
            // Accepted risk: permissionless Token-2022 support means we cannot
            // prevent a mint authority from choosing PermanentDelegate without
            // excluding those mints entirely. A delegate can debit this
            // market's vault behind Manifest's accounting. The direct-market
            // damage is isolated to the market being created; users must not
            // treat other markets as collateral for it.
            if let Ok(extension) = pool_mint.get_extension::<PermanentDelegate>() {
                let permanent_delegate: Option<Pubkey> = extension.delegate.into();
                if permanent_delegate.is_some() {
                    solana_program::msg!(
                        "Warning, you are creating a market with a permanent delegate. There is no loss of funds protection for funds on this market"
                    );
                }
            }
        }
    }

    {
        // Create the base and quote vaults of this market
        let rent: Rent = Rent::get()?;
        for (token_account, mint, bump) in [
            (base_vault.as_ref(), base_mint.as_ref(), base_vault_bump),
            (quote_vault.as_ref(), quote_mint.as_ref(), quote_vault_bump),
        ] {
            // We dont have to deserialize the mint, just check the owner.
            let is_mint_22: bool = mint.owner_pubkey() == spl_token_2022::id();
            let token_program_for_mint: Pubkey = if is_mint_22 {
                spl_token_2022::id()
            } else {
                spl_token::id()
            };

            let seeds: Vec<Vec<u8>> = vec![
                b"vault".to_vec(),
                market.pubkey().as_ref().to_vec(),
                mint.pubkey().as_ref().to_vec(),
                vec![bump],
            ];

            if is_mint_22 {
                let mint_data: pinocchio::account::Ref<[u8]> = mint.try_borrow()?;
                let space: usize = try_calculate_account_len_from_mint_data(&mint_data, &[])
                    .map_err(to_program_error)?;
                create_account(
                    payer.as_ref(),
                    token_account,
                    system_program.as_ref(),
                    &token_program_for_mint,
                    &rent,
                    space as u64,
                    seeds,
                )?;
                invoke(
                    &spl_token_2022::instruction::initialize_account3(
                        &token_program_for_mint,
                        token_account.pubkey(),
                        mint.pubkey(),
                        token_account.pubkey(),
                    )
                    .map_err(to_program_error)?,
                    // initialize_account3 names the account and its mint.
                    &[token_account, mint],
                )?;
            } else {
                let space: usize = spl_token::state::Account::LEN;
                create_account(
                    payer.as_ref(),
                    token_account,
                    system_program.as_ref(),
                    &token_program_for_mint,
                    &rent,
                    space as u64,
                    seeds,
                )?;
                invoke(
                    &spl_token::instruction::initialize_account3(
                        &token_program_for_mint,
                        token_account.pubkey(),
                        mint.pubkey(),
                        token_account.pubkey(),
                    )
                    .map_err(to_program_error)?,
                    // initialize_account3 names the account and its mint.
                    &[token_account, mint],
                )?;
            }
        }

        // Do not need to initialize with the system program because it is
        // assumed that it is done already and loaded with rent. That is not at
        // a PDA because we do not want to be restricted to a single market for
        // a pair. If there is lock contention and hotspotting for one market,
        // it could be useful to have a second where it is easier to land
        // transactions. That protection is worth the possibility that users
        // would use an inactive market when multiple exist.

        // Setup the empty market
        #[allow(unused_mut)]
        let mut empty_market_fixed: MarketFixed = MarketFixed::new_empty_with_vaults(
            &base_mint,
            &quote_mint,
            *base_vault.info.pubkey(),
            base_vault_bump,
            *quote_vault.info.pubkey(),
            quote_vault_bump,
        );
        // Cache the global account addresses so that global trades on this
        // market never have to derive them.
        #[cfg(not(feature = "certora"))]
        {
            let (base_global, _) = get_global_address(base_mint.info.pubkey());
            let (quote_global, _) = get_global_address(quote_mint.info.pubkey());
            empty_market_fixed.set_base_global(base_global);
            empty_market_fixed.set_quote_global(quote_global);
        }
        assert_eq!(market.data_len(), size_of::<MarketFixed>());

        let market_bytes: &mut [u8] = &mut market.try_borrow_mut()?[..];
        *get_mut_helper::<MarketFixed>(market_bytes, 0_u32) = empty_market_fixed;

        emit_stack(CreateMarketLog {
            market: *market.pubkey(),
            creator: *payer.pubkey(),
            base_mint: *base_mint.info.pubkey(),
            quote_mint: *quote_mint.info.pubkey(),
        })?;
    }

    // Leave a free block on the market so takers can use and leave it.
    expand_market_if_needed(&payer, &market)?;

    Ok(())
}
