use std::mem::size_of;

use borsh::{BorshDeserialize, BorshSerialize};
use hypertree::{
    get_helper, get_mut_helper, DataIndex, FreeList, HyperTreeReadOperations,
    HyperTreeValueIteratorTrait, HyperTreeWriteOperations, RBNode, NIL,
};
use manifest::{
    program::{
        batch_update::{CancelOrderParams, PlaceOrderParams},
        get_dynamic_account, get_mut_dynamic_account, invoke_passthrough, invoke_passthrough_refs,
        ManifestInstruction,
    },
    quantities::{BaseAtoms, QuoteAtoms, QuoteAtomsPerBaseAtom, WrapperU64},
    state::{
        claimed_seat::ClaimedSeat, utils::get_now_slot, DynamicAccount, MarketFixed, OrderType,
        RestingOrder, NO_EXPIRATION_LAST_VALID_SLOT,
    },
    validation::{next_account_info, AccountViewExt, ManifestAccountInfo, Program, Signer},
};
use pinocchio::{
    account::{AccountView, Ref, RefMut},
    ProgramResult,
};
use solana_program::{program::get_return_data, pubkey::Pubkey};
use solana_sdk_ids::system_program;

use crate::{
    loader::{check_signer, WrapperStateAccountInfo},
    market_info::MarketInfo,
    open_order::WrapperOpenOrder,
    wrapper_state::ManifestWrapperStateFixed,
};

use super::shared::{
    ensure_free_slots, get_market_info_index_for_market, sync_fast, CancelMatcher, OpenOrdersList,
    UnusedWrapperFreeListPadding,
};

#[derive(BorshDeserialize, BorshSerialize, Clone)]
pub struct WrapperPlaceOrderParams {
    client_order_id: u64,
    base_atoms: u64,
    price_mantissa: u32,
    price_exponent: i8,
    is_bid: bool,
    last_valid_slot: u32,
    order_type: OrderType,
}
impl WrapperPlaceOrderParams {
    pub fn new(
        client_order_id: u64,
        base_atoms: u64,
        price_mantissa: u32,
        price_exponent: i8,
        is_bid: bool,
        last_valid_slot: u32,
        order_type: OrderType,
    ) -> Self {
        WrapperPlaceOrderParams {
            client_order_id,
            base_atoms,
            price_mantissa,
            price_exponent,
            is_bid,
            last_valid_slot,
            order_type,
        }
    }
}

// TODO: Note that this does not cancel reverse orders which have been created
// at a new sequence number and address (partial fill).
#[derive(BorshDeserialize, BorshSerialize, Clone)]
pub struct WrapperCancelOrderParams {
    client_order_id: u64,
}
impl WrapperCancelOrderParams {
    pub fn new(client_order_id: u64) -> Self {
        WrapperCancelOrderParams { client_order_id }
    }
    pub fn client_order_id(&self) -> u64 {
        self.client_order_id
    }
}

#[derive(BorshDeserialize, BorshSerialize)]
pub struct WrapperBatchUpdateParams {
    pub cancels: Vec<WrapperCancelOrderParams>,
    pub cancel_all: bool,
    pub orders: Vec<WrapperPlaceOrderParams>,
}
impl WrapperBatchUpdateParams {
    pub fn new(
        cancels: Vec<WrapperCancelOrderParams>,
        cancel_all: bool,
        orders: Vec<WrapperPlaceOrderParams>,
    ) -> Self {
        WrapperBatchUpdateParams {
            cancels,
            cancel_all,
            orders,
        }
    }
}

/// Match the deployed wrapper's full core-book search for direct orders.
/// The wrapper's own orders have already been matched while syncing.
fn prepare_cancel_all(
    matcher: &mut CancelMatcher,
    market: &ManifestAccountInfo<MarketFixed>,
    trader_index: DataIndex,
) {
    let market_data: Ref<[u8]> = market.try_borrow().unwrap();
    let market_ref = get_dynamic_account::<MarketFixed>(&market_data);
    for (index, resting_order) in market_ref.get_bids().iter::<RestingOrder>() {
        if resting_order.get_trader_index() != trader_index {
            continue;
        }
        let sequence_number = resting_order.get_sequence_number();
        let already_cancelled = matcher
            .core_cancels
            .iter()
            .any(|cancel| cancel.order_sequence_number() == sequence_number);
        if !already_cancelled {
            matcher.core_cancels.push(CancelOrderParams::new_with_hint(
                sequence_number,
                Some(index),
            ));
            if matcher.needs_quote {
                matcher.freed_quote_atoms += resting_order
                    .get_price()
                    .checked_quote_for_base(resting_order.get_num_base_atoms(), true)
                    .unwrap();
            }
        }
    }
    for (index, resting_order) in market_ref.get_asks().iter::<RestingOrder>() {
        if resting_order.get_trader_index() != trader_index {
            continue;
        }
        let sequence_number = resting_order.get_sequence_number();
        let already_cancelled = matcher
            .core_cancels
            .iter()
            .any(|cancel| cancel.order_sequence_number() == sequence_number);
        if !already_cancelled {
            matcher.core_cancels.push(CancelOrderParams::new_with_hint(
                sequence_number,
                Some(index),
            ));
            if matcher.needs_base {
                matcher.freed_base_atoms += resting_order.get_num_base_atoms();
            }
        }
    }
}

/// Find the first unexpired opposing price without changing the book.
/// An empty book has no crossing price, including at MIN and MAX prices.
fn best_opposing_price(
    market: &ManifestAccountInfo<MarketFixed>,
    is_bid: bool,
    now_slot: u32,
    cancels: &[CancelOrderParams],
) -> Option<QuoteAtomsPerBaseAtom> {
    let market_data: Ref<[u8]> = market.try_borrow().unwrap();
    let market_ref = get_dynamic_account::<MarketFixed>(&market_data);
    let book = if is_bid {
        market_ref.get_asks()
    } else {
        market_ref.get_bids()
    };
    let mut index = book.get_max_index();
    while index != NIL {
        let order = get_helper::<RBNode<RestingOrder>>(market_ref.dynamic, index).get_value();
        if !order.is_expired(now_slot)
            && order.get_num_base_atoms() != BaseAtoms::ZERO
            && !cancels
                .iter()
                .any(|cancel| cancel.order_sequence_number() == order.get_sequence_number())
        {
            return Some(order.get_price());
        }
        index = book.get_next_lower_index::<RestingOrder>(index);
    }
    None
}

/// Reused across core calls so a mixed batch does not allocate a buffer for
/// every remaining suffix of the original orders.
struct PreparedOrders {
    orders: Vec<PlaceOrderParams>,
    original_indices: Vec<usize>,
}

/// Prepare a prefix whose PostOnly checks can use the current book, excluding
/// pending cancellations. Return the number of input orders inspected.
fn prepare_orders(
    orders: &[WrapperPlaceOrderParams],
    mut remaining_base_atoms: BaseAtoms,
    mut remaining_quote_atoms: QuoteAtoms,
    market: &ManifestAccountInfo<MarketFixed>,
    now_slot: u32,
    cancels: &[CancelOrderParams],
    prepared: &mut PreparedOrders,
) -> usize {
    prepared.orders.clear();
    prepared.original_indices.clear();
    // Some(None) caches an empty side. Only PostOnly orders read book prices.
    let mut best_ask_price: Option<Option<QuoteAtomsPerBaseAtom>> = None;
    let mut best_bid_price: Option<Option<QuoteAtomsPerBaseAtom>> = None;
    let mut posted_bid_price: Option<QuoteAtomsPerBaseAtom> = None;
    let mut posted_ask_price: Option<QuoteAtomsPerBaseAtom> = None;

    for (i, order) in orders.iter().enumerate() {
        // Validate prices even when the funds check would drop the order.
        assert!(
            (QuoteAtomsPerBaseAtom::MIN_EXP..=QuoteAtomsPerBaseAtom::MAX_EXP)
                .contains(&order.price_exponent)
        );
        let price = QuoteAtomsPerBaseAtom::try_from_mantissa_and_exponent(
            order.price_mantissa,
            order.price_exponent,
        )
        .unwrap();
        if order.order_type == OrderType::PostOnly {
            if let Some(previous) = prepared.orders.last() {
                // A taker can fill or create reverse orders. Execute that
                // prefix before checking a later PostOnly against the book.
                if previous.order_type() != OrderType::PostOnly {
                    return i;
                }
                // Every earlier forwarded order in this prefix is PostOnly:
                // a PostOnly following any other type ends the prefix above.
                // Their posted prices are predictable without simulating fills.
                let previous_price = previous.try_price().unwrap();
                let posted = if previous.is_bid() {
                    &mut posted_bid_price
                } else {
                    &mut posted_ask_price
                };
                *posted = Some(posted.map_or(previous_price, |best| {
                    if previous.is_bid() {
                        best.max(previous_price)
                    } else {
                        best.min(previous_price)
                    }
                }));
            }
            let best = if order.is_bid {
                &mut best_ask_price
            } else {
                &mut best_bid_price
            };
            let live_price = *best.get_or_insert_with(|| {
                best_opposing_price(market, order.is_bid, now_slot, cancels)
            });
            let posted_price = if order.is_bid {
                posted_ask_price
            } else {
                posted_bid_price
            };
            let crosses = |best| {
                if order.is_bid {
                    price >= best
                } else {
                    price <= best
                }
            };
            if live_price.is_some_and(crosses) || posted_price.is_some_and(crosses) {
                continue;
            }
        }

        if order.order_type != OrderType::Global {
            if order.is_bid {
                let desired: QuoteAtoms = BaseAtoms::new(order.base_atoms)
                    .checked_mul(price, true)
                    .unwrap();
                if desired > remaining_quote_atoms {
                    continue;
                }
                remaining_quote_atoms -= desired;
            } else {
                let desired = BaseAtoms::new(order.base_atoms);
                if desired > remaining_base_atoms {
                    continue;
                }
                remaining_base_atoms -= desired;
            }
        }
        if order.base_atoms == 0 {
            continue;
        }
        let expiration = if order.last_valid_slot != NO_EXPIRATION_LAST_VALID_SLOT
            && order.last_valid_slot < 10_000_000
            && !order.order_type.is_reversible()
        {
            now_slot + order.last_valid_slot
        } else {
            order.last_valid_slot
        };
        prepared.orders.push(PlaceOrderParams::new(
            order.base_atoms,
            order.price_mantissa,
            order.price_exponent,
            order.is_bid,
            order.order_type,
            expiration,
        ));
        prepared.original_indices.push(i);
    }
    orders.len()
}

/// Forwards the batch to the core.
///
/// CU note: besides the 1,000 CU invoke base cost, the runtime charges every
/// account passed to a CPI `data_len / 250` CU when it translates the
/// caller's `AccountView`s (`cpi_bytes_per_unit`), whether or not account
/// data direct mapping is enabled; direct mapping only removes the copy of
/// the data, not the charge. For the market that is 4 CU per KB per batch
/// update, e.g. about 4,000 CU on a 1 MB market, and the only ways around it
/// are smaller markets or not going through a CPI.
fn execute_cpi(
    accounts: &[AccountView],
    trader_index_hint: Option<DataIndex>,
    core_cancels: &[CancelOrderParams],
    core_orders: &[PlaceOrderParams],
) -> ProgramResult {
    // Serialize straight into one buffer, sized for what goes in it. Building
    // the discriminant and the params as their own vectors and concatenating
    // them allocated three times and copied the params twice.
    let mut data: Vec<u8> =
        Vec::with_capacity(1 + 5 + 4 + core_cancels.len() * 13 + 4 + core_orders.len() * 19);
    data.push(ManifestInstruction::BatchUpdate as u8);
    // Borsh encodes these fields exactly as BatchUpdateParams, including the
    // slice lengths. Borrow them so subsequent prefixes can reuse the buffers.
    (trader_index_hint, core_cancels, core_orders)
        .serialize(&mut data)
        .map_err(manifest::validation::io_to_program_error)?;

    // The first two accounts are this program's state and the manifest
    // program itself; the rest are passed through to manifest as they stand,
    // with the flags this program sees on them.
    invoke_passthrough(&manifest::id(), &accounts[2..], &data)
}

/// Removes the cancelled orders from the wrapper's open orders.
fn process_cancels(
    wrapper_state: &WrapperStateAccountInfo,
    cancel_indices: &[DataIndex],
    market_info_index: DataIndex,
) {
    // Placement-only batches have no list/free-list bookkeeping to perform.
    if cancel_indices.is_empty() {
        return;
    }
    let mut wrapper_data: RefMut<[u8]> = wrapper_state.info.try_borrow_mut().unwrap();
    let wrapper: DynamicAccount<&mut ManifestWrapperStateFixed, &mut [u8]> =
        get_mut_dynamic_account(&mut wrapper_data);
    let (orders_root_index, mut num_open_global_orders): (DataIndex, u32) = {
        let market_info: &MarketInfo =
            get_helper::<RBNode<MarketInfo>>(wrapper.dynamic, market_info_index).get_value();
        (
            market_info.orders_root_index,
            market_info.num_open_global_orders,
        )
    };
    for order_wrapper_index in cancel_indices {
        if get_helper::<RBNode<WrapperOpenOrder>>(wrapper.dynamic, *order_wrapper_index)
            .get_value()
            .get_order_type()
            == OrderType::Global
        {
            num_open_global_orders = num_open_global_orders.saturating_sub(1);
        }
    }
    let orders_root_index: DataIndex = {
        let mut open_orders: OpenOrdersList =
            OpenOrdersList::new(wrapper.dynamic, orders_root_index);
        for order_wrapper_index in cancel_indices {
            open_orders.remove_by_index(*order_wrapper_index);
        }
        open_orders.get_root_index()
    };
    let market_info: &mut MarketInfo =
        get_mut_helper::<RBNode<MarketInfo>>(wrapper.dynamic, market_info_index).get_mut_value();
    market_info.orders_root_index = orders_root_index;
    market_info.num_open_global_orders = num_open_global_orders;

    let mut free_list: FreeList<UnusedWrapperFreeListPadding> =
        FreeList::new(wrapper.dynamic, wrapper.fixed.free_list_head_index);
    for order_wrapper_index in cancel_indices {
        if *order_wrapper_index != NIL {
            free_list.add(*order_wrapper_index);
        }
    }
    // Update free list head.
    wrapper.fixed.free_list_head_index = free_list.get_head();
}

/// Records the orders that rested on the core in the wrapper's open orders.
fn process_orders<'a>(
    payer: &Signer<'a>,
    system_program: &Program<'a>,
    wrapper_state: &WrapperStateAccountInfo<'a>,
    orders: &[WrapperPlaceOrderParams],
    original_indices: &[usize],
    market_info_index: DataIndex,
) -> ProgramResult {
    // A successful core batch returns one record per forwarded placement.
    // With none forwarded, avoid allocating/copying its empty return vector.
    if original_indices.is_empty() {
        return Ok(());
    }
    // The core returns `BatchUpdateReturn`, borsh: a u32 count followed by
    // (u64 order sequence number, u32 order index) records. Read them in
    // place instead of deserializing into vectors.
    let (_, return_data): (Pubkey, Vec<u8>) = get_return_data().unwrap();
    let num_records: usize = u32::from_le_bytes(return_data[..4].try_into().unwrap()) as usize;
    let records: &[u8] = &return_data[4..4 + num_records * 12];
    let record = |index: usize| -> (u64, DataIndex) {
        let bytes: &[u8] = &records[index * 12..index * 12 + 12];
        (
            u64::from_le_bytes(bytes[..8].try_into().unwrap()),
            u32::from_le_bytes(bytes[8..12].try_into().unwrap()),
        )
    };

    // Order index is NIL when it did not rest, those need no slot. Grow the
    // wrapper once for all the rest instead of checking per order.
    let num_resting: usize = (0..num_records).filter(|&i| record(i).1 != NIL).count();
    if num_resting == 0 {
        return Ok(());
    }
    ensure_free_slots(wrapper_state, payer, system_program, num_resting)?;

    let mut wrapper_data: RefMut<[u8]> = wrapper_state.info.try_borrow_mut().unwrap();
    let wrapper: DynamicAccount<&mut ManifestWrapperStateFixed, &mut [u8]> =
        get_mut_dynamic_account(&mut wrapper_data);
    let (mut orders_root_index, mut num_open_global_orders): (DataIndex, u32) = {
        let market_info: &MarketInfo =
            get_helper::<RBNode<MarketInfo>>(wrapper.dynamic, market_info_index).get_value();
        (
            market_info.orders_root_index,
            market_info.num_open_global_orders,
        )
    };
    let mut free_list_head_index: DataIndex = wrapper.fixed.free_list_head_index;
    for index in 0..num_records {
        let (order_sequence_number, order_index): (u64, DataIndex) = record(index);
        if order_index == NIL {
            continue;
        }
        let wrapper_new_order_index: DataIndex = {
            let mut free_list: FreeList<UnusedWrapperFreeListPadding> =
                FreeList::new(wrapper.dynamic, free_list_head_index);
            let new_index: DataIndex = free_list.remove();
            free_list_head_index = free_list.get_head();
            new_index
        };

        let original_order: &WrapperPlaceOrderParams = &orders[original_indices[index]];
        // Price and remaining size are left at zero here and filled in by the
        // sync that follows every placement in `process_batch_update`, which
        // is the only thing that knows how much of the order actually rested.
        // That sync is not optional: a zero here would otherwise be read as an
        // order that frees nothing when it is cancelled, and a later
        // cancel and replace would drop the replacement for want of funds.
        let order: WrapperOpenOrder = WrapperOpenOrder::new(
            original_order.client_order_id,
            order_sequence_number,
            QuoteAtomsPerBaseAtom::ZERO,
            BaseAtoms::ZERO,
            original_order.last_valid_slot,
            order_index,
            original_order.is_bid,
            original_order.order_type,
        );
        if original_order.order_type == OrderType::Global {
            num_open_global_orders += 1;
        }

        let mut open_orders: OpenOrdersList =
            OpenOrdersList::new(wrapper.dynamic, orders_root_index);
        open_orders.insert(wrapper_new_order_index, order);
        orders_root_index = open_orders.get_root_index();
    }
    wrapper.fixed.free_list_head_index = free_list_head_index;
    let market_info: &mut MarketInfo =
        get_mut_helper::<RBNode<MarketInfo>>(wrapper.dynamic, market_info_index).get_mut_value();
    market_info.orders_root_index = orders_root_index;
    market_info.num_open_global_orders = num_open_global_orders;
    Ok(())
}

// Fee here is WRAPPER_FEE_LAMPORTS stored on the wrapper state. This is stored
// on the wrapper state because it prevents the need for a contentious extra
// write lock. Users who do not wish to pay this fee should use their own
// wrapper or interact directly with the manifest program.
fn collect_fee<'a>(
    payer: &Signer<'a>,
    wrapper_state: &WrapperStateAccountInfo<'a>,
) -> ProgramResult {
    // The system program's transfer, encoded directly. Building it through
    // `system_instruction::transfer` bincode encodes the instruction enum and
    // allocates a vector for the data and another for the account metas, and
    // this runs on every batch update.
    let mut data: [u8; 12] = [0; 12];
    data[0] = 2;
    data[4..].copy_from_slice(&crate::WRAPPER_FEE_LAMPORTS.to_le_bytes());
    invoke_passthrough_refs(
        &system_program::id(),
        &[payer.as_ref(), wrapper_state.info],
        &data,
    )?;

    Ok(())
}

pub(crate) fn process_batch_update(
    _program_id: &Pubkey,
    accounts: &[AccountView],
    data: &[u8],
) -> ProgramResult {
    let account_iter: &mut std::slice::Iter<AccountView> = &mut accounts.iter();
    let wrapper_state: WrapperStateAccountInfo =
        WrapperStateAccountInfo::new(next_account_info(account_iter)?)?;
    let _manifest_program: Program =
        Program::new(next_account_info(account_iter)?, &manifest::id())?;
    let payer: Signer = Signer::new(next_account_info(account_iter)?)?;
    let market: ManifestAccountInfo<MarketFixed> =
        ManifestAccountInfo::<MarketFixed>::new(next_account_info(account_iter)?)?;
    let system_program: Program =
        Program::new(next_account_info(account_iter)?, &system_program::id())?;

    check_signer(&wrapper_state, payer.pubkey());
    let market_info_index: DataIndex =
        get_market_info_index_for_market(&wrapper_state, market.pubkey());

    // One clock read for the whole instruction.
    let now_slot: u32 = get_now_slot();

    // Cancels are mutable because the user may have mistakenly sent the same
    // one multiple times and the wrapper will take the responsibility for
    // deduping before forwarding to the core.
    let WrapperBatchUpdateParams {
        orders,
        cancel_all,
        cancels,
    } = WrapperBatchUpdateParams::try_from_slice(data)
        .map_err(manifest::validation::io_to_program_error)?;

    // Only a placement needs a seat. Defrag reclaims a seat only once it
    // holds no balance and no orders, so a batch that places nothing has
    // nothing on the core to cancel and no reason to pay to restore one.
    if !orders.is_empty() {
        super::shared::ensure_market_seat(&market, &payer, &_manifest_program, &system_program)?;
    }

    // Only price the funds that cancels free up when a new order needs the
    // balance check.
    let needs_base: bool = orders.iter().any(|order: &WrapperPlaceOrderParams| {
        !order.is_bid && order.order_type != OrderType::Global
    });
    let needs_quote: bool = orders.iter().any(|order: &WrapperPlaceOrderParams| {
        order.is_bid && order.order_type != OrderType::Global
    });

    // Sync to get all existing orders and balances fresh (needed for
    // modifying user orders for insufficient funds), matching the cancels
    // against the open orders in the same walk.
    let mut matcher: CancelMatcher =
        CancelMatcher::new(&cancels, cancel_all, needs_base, needs_quote);
    sync_fast(
        &wrapper_state,
        &market,
        market_info_index,
        now_slot,
        false,
        Some(&mut matcher),
    )?;

    let market_info: MarketInfo = {
        let wrapper_data: Ref<[u8]> = wrapper_state.info.try_borrow()?;
        let (_fixed_data, wrapper_dynamic_data) =
            wrapper_data.split_at(size_of::<ManifestWrapperStateFixed>());
        *get_helper::<RBNode<MarketInfo>>(wrapper_dynamic_data, market_info_index).get_value()
    };
    let trader_index_hint: Option<DataIndex> = Some(market_info.trader_index);
    // No seat and no placement to restore it for. The trader has nothing on
    // the core and the sync above dropped whatever this wrapper still cached,
    // so there is no core call to make.
    if market_info.trader_index == NIL {
        collect_fee(&payer, &wrapper_state)?;
        return Ok(());
    }
    if cancel_all {
        prepare_cancel_all(&mut matcher, &market, market_info.trader_index);
    }
    let mut remaining_base_atoms = market_info.base_balance + matcher.freed_base_atoms;
    let mut remaining_quote_atoms = market_info.quote_balance + matcher.freed_quote_atoms;
    let CancelMatcher {
        wrapper_indices: mut cancel_indices,
        mut core_cancels,
        ..
    } = matcher;
    let mut prepared = PreparedOrders {
        orders: Vec::with_capacity(orders.len()),
        original_indices: Vec::with_capacity(orders.len()),
    };
    let mut remaining_orders = orders.as_slice();
    let mut placed_orders = false;
    loop {
        let inspected = prepare_orders(
            remaining_orders,
            remaining_base_atoms,
            remaining_quote_atoms,
            &market,
            now_slot,
            &core_cancels,
            &mut prepared,
        );
        // A later prefix with no forwarded orders needs no further core call.
        // Pending cancels were already applied by the first call.
        if prepared.orders.is_empty() && placed_orders {
            break;
        }
        placed_orders |= !prepared.orders.is_empty();
        execute_cpi(accounts, trader_index_hint, &core_cancels, &prepared.orders)?;
        process_cancels(&wrapper_state, &cancel_indices, market_info_index);
        let (processed_orders, rest) = remaining_orders.split_at(inspected);
        // Consume this CPI's return data before the next CPI overwrites it.
        process_orders(
            &payer,
            &system_program,
            &wrapper_state,
            processed_orders,
            &prepared.original_indices,
            market_info_index,
        )?;
        if rest.is_empty() {
            break;
        }
        remaining_orders = rest;
        // Cancels execute once. Later prefixes read the actual balance after
        // fills and resting orders, without reserving their funds twice.
        core_cancels.clear();
        cancel_indices.clear();
        let market_data = market.try_borrow()?;
        let market_ref = get_dynamic_account::<MarketFixed>(&market_data);
        let seat = get_helper::<RBNode<ClaimedSeat>>(market_ref.dynamic, market_info.trader_index)
            .get_value();
        remaining_base_atoms = seat.base_withdrawable_balance;
        remaining_quote_atoms = seat.quote_withdrawable_balance;
    }

    // Forwarding a placement runs the core's matching loop, and that loop can
    // change this trader's other orders in ways nothing here can predict: it
    // fills them, and it removes any it finds expired on its way down the
    // book. So whenever an order was placed, read the orders back rather than
    // declaring the view exact.
    //
    // Seat quote volume was used for this and is not enough. The matching loop
    // removes an expired maker without recording any volume, and a fill of a
    // small amount at a low price rounds down to zero quote atoms, so either
    // can move this trader's orders while the volume stands still.
    //
    // A batch that only cancels runs no matching, so nothing can have touched
    // the orders that this instruction did not touch itself, and the cheap
    // path still applies. This is also what heals a view that went stale
    // outside the wrapper, see `sync_fast`: the next placement re-reads.
    sync_fast(
        &wrapper_state,
        &market,
        market_info_index,
        now_slot,
        !placed_orders,
        None,
    )?;

    // Collect fee.
    collect_fee(&payer, &wrapper_state)?;

    Ok(())
}
