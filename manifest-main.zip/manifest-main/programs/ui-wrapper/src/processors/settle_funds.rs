use manifest::validation::{next_account_info, AccountViewExt};
use pinocchio::{
    account::{AccountView, Ref, RefMut},
    error::ProgramError,
    ProgramResult,
};

use borsh::{BorshDeserialize, BorshSerialize};
use hypertree::{get_mut_helper, trace, DataIndex, RBNode};
use manifest::{
    logs::emit_stack,
    program::{get_dynamic_account, get_mut_dynamic_account, invoke, withdraw_instruction},
    quantities::{QuoteAtoms, WrapperU64},
    state::{DynamicAccount, MarketFixed, MarketRef},
    validation::{ManifestAccountInfo, Program, Signer},
};
use solana_program::{pubkey, pubkey::Pubkey};

use crate::{
    logs::{PlatformFeeLog, ReferrerFeeLog},
    market_info::MarketInfo,
    wrapper_user::ManifestWrapperUserFixed,
};

use super::shared::{
    check_signer, get_market_info_index_for_market, sync_fast, WrapperStateAccountInfo,
};

const FEE_DENOMINATOR: u128 = 10u128.pow(9);
#[cfg(not(feature = "test"))]
const FEE_AUTHORITY: Pubkey = pubkey!("B6dmr2UAn2wgjdm3T4N1Vjd8oPYRRTguByW7AEngkeL6");
#[cfg(feature = "test")]
const FEE_AUTHORITY: Pubkey = pubkey!("2iXtA8oeZqUU5pofxK971TCEvFGfems2AcDRaZHKD2pQ");

#[derive(BorshDeserialize, BorshSerialize, Clone)]
pub struct WrapperSettleFundsParams {
    fee_mantissa: u32,
    platform_fee_percent: u8,
}
impl WrapperSettleFundsParams {
    pub fn new(fee_mantissa: u32, platform_fee_percent: u8) -> Self {
        WrapperSettleFundsParams {
            fee_mantissa,
            platform_fee_percent,
        }
    }
}

pub(crate) fn process_settle_funds(
    _program_id: &Pubkey,
    accounts: &[AccountView],
    data: &[u8],
) -> ProgramResult {
    let account_iter: &mut std::slice::Iter<AccountView> = &mut accounts.iter();
    let wrapper_state: WrapperStateAccountInfo =
        WrapperStateAccountInfo::new(next_account_info(account_iter)?)?;
    let owner: Signer = Signer::new(next_account_info(account_iter)?)?;
    let trader_token_account_base: &AccountView = next_account_info(account_iter)?;
    let trader_token_account_quote: &AccountView = next_account_info(account_iter)?;
    // Normal UI settlement collects payable fees atomically with emptying the
    // seat. If core activity bypasses settlement, defrag could close the market
    // before those fees are collected; this path requires a live market.
    let market: ManifestAccountInfo<MarketFixed> =
        ManifestAccountInfo::<MarketFixed>::new(next_account_info(account_iter)?)?;
    let vault_base: &AccountView = next_account_info(account_iter)?;
    let vault_quote: &AccountView = next_account_info(account_iter)?;
    let mint_base: &AccountView = next_account_info(account_iter)?;
    let mint_quote: &AccountView = next_account_info(account_iter)?;
    let token_program_base: &AccountView = next_account_info(account_iter)?;
    let token_program_quote: &AccountView = next_account_info(account_iter)?;
    let manifest_program: Program =
        Program::new(next_account_info(account_iter)?, &manifest::id())?;
    let fee_authority: Signer = Signer::new(next_account_info(account_iter)?)?;
    let platform_token_account: &AccountView = next_account_info(account_iter)?;
    let referrer_token_account: Result<&AccountView, ProgramError> =
        next_account_info(account_iter);

    check_signer(&wrapper_state, owner.pubkey());
    if *fee_authority.pubkey() != FEE_AUTHORITY {
        return Err(ProgramError::InvalidArgument);
    }
    let market_info_index: DataIndex =
        get_market_info_index_for_market(&wrapper_state, market.pubkey());

    // Do an initial sync to update withdrawable balances and volume traded for fee calculation.
    sync_fast(&wrapper_state, &market, market_info_index)?;

    let mut wrapper_data: RefMut<[u8]> = wrapper_state.info.try_borrow_mut()?;
    let mut wrapper: DynamicAccount<&mut ManifestWrapperUserFixed, &mut [u8]> =
        get_mut_dynamic_account(&mut wrapper_data);

    let market_info: &mut MarketInfo =
        get_mut_helper::<RBNode<MarketInfo>>(&mut wrapper.dynamic, market_info_index)
            .get_mut_value();
    let trader_index: DataIndex = market_info.trader_index;

    let WrapperSettleFundsParams {
        fee_mantissa,
        platform_fee_percent,
    } = WrapperSettleFundsParams::try_from_slice(data)
        .map_err(manifest::validation::io_to_program_error)?;
    let fee_mantissa = (fee_mantissa as u128).min(FEE_DENOMINATOR);
    if fee_mantissa == 0 {
        return Err(ProgramError::InvalidArgument);
    }

    // limits:
    // quote_volume_unpaid = [0..u64::MAX]
    // fee_mantissa = [0..FEE_DENOMINATOR]
    // fee_atoms = [0..u64::MAX]
    // intermediate results can extend above u64
    let fee_atoms =
        market_info.quote_volume_unpaid.as_u64() as u128 * fee_mantissa / FEE_DENOMINATOR;
    // limits:
    // quote_volume_paid = [0..quote_volume_unpaid] safe to cast to u64
    // intermediate results can extend above u64
    let quote_volume_paid: QuoteAtoms =
        QuoteAtoms::new((fee_atoms * FEE_DENOMINATOR / fee_mantissa) as u64);

    let MarketInfo {
        base_balance,
        quote_balance,
        ..
    } = market_info.clone();

    drop(wrapper_data);

    let quote_mint_decimals = {
        let market_data: Ref<[u8]> = market.try_borrow()?;
        let dynamic_account: MarketRef = get_dynamic_account(&market_data);
        dynamic_account.fixed.get_quote_mint_decimals()
    };

    trace!("base_balance:{base_balance:?} quote_balance:{quote_balance:?} fee_atoms:{fee_atoms} quote_volume_paid:{quote_volume_paid:?}");

    if trader_index != hypertree::NIL {
        // Settle withdrawable base tokens.
        invoke(
            &withdraw_instruction(
                market.pubkey(),
                owner.pubkey(),
                mint_base.pubkey(),
                base_balance.as_u64(),
                trader_token_account_base.pubkey(),
                *token_program_base.pubkey(),
                Some(trader_index),
            ),
            &[
                market.info,
                owner.info,
                mint_base,
                trader_token_account_base,
                vault_base,
                token_program_base,
                manifest_program.info,
            ],
        )?;

        // Settle withdrawable quote tokens.
        invoke(
            &withdraw_instruction(
                market.pubkey(),
                owner.pubkey(),
                mint_quote.pubkey(),
                quote_balance.as_u64(),
                trader_token_account_quote.pubkey(),
                *token_program_quote.pubkey(),
                Some(trader_index),
            ),
            &[
                market.info,
                owner.info,
                mint_quote,
                trader_token_account_quote,
                vault_quote,
                token_program_quote,
                manifest_program.info,
            ],
        )?;
    }

    // limits:
    // fee_atoms = [0..u64::MAX]
    // platform_fee_atoms = [0..fee_atoms]
    // intermediate results can extend above u64
    let platform_fee_atoms = if referrer_token_account.is_ok() {
        (fee_atoms * platform_fee_percent.min(100) as u128 / 100) as u64
    } else {
        fee_atoms as u64
    };

    trace!("platform_fee_atoms:{platform_fee_atoms}");

    if *token_program_quote.pubkey() == spl_token_2022::id() {
        invoke(
            &spl_token_2022::instruction::transfer_checked(
                token_program_quote.pubkey(),
                trader_token_account_quote.pubkey(),
                mint_quote.pubkey(),
                platform_token_account.pubkey(),
                owner.pubkey(),
                &[],
                platform_fee_atoms,
                quote_mint_decimals,
            )
            .map_err(manifest::validation::to_program_error)?,
            &[
                token_program_quote,
                trader_token_account_quote,
                mint_quote,
                platform_token_account,
                owner.as_ref(),
            ],
        )?;
    } else {
        invoke(
            &spl_token::instruction::transfer(
                token_program_quote.pubkey(),
                trader_token_account_quote.pubkey(),
                platform_token_account.pubkey(),
                owner.pubkey(),
                &[],
                platform_fee_atoms,
            )
            .map_err(manifest::validation::to_program_error)?,
            &[
                token_program_quote,
                trader_token_account_quote,
                platform_token_account,
                owner.info,
            ],
        )?;
    }

    emit_stack(PlatformFeeLog {
        market: *market.pubkey(),
        user: *owner.pubkey(),
        mint: *mint_quote.pubkey(),
        platform_token_account: *platform_token_account.pubkey(),
        platform_fee: platform_fee_atoms,
    })?;

    if let Ok(referrer_token_account) = referrer_token_account {
        // saturating_sub not needed, but doesn't hurt
        let referrer_fee_atoms = (fee_atoms as u64).saturating_sub(platform_fee_atoms);

        if *token_program_quote.pubkey() == spl_token_2022::id() {
            invoke(
                &spl_token_2022::instruction::transfer_checked(
                    token_program_quote.pubkey(),
                    trader_token_account_quote.pubkey(),
                    mint_quote.pubkey(),
                    referrer_token_account.pubkey(),
                    owner.pubkey(),
                    &[],
                    referrer_fee_atoms,
                    quote_mint_decimals,
                )
                .map_err(manifest::validation::to_program_error)?,
                &[
                    token_program_quote,
                    trader_token_account_quote,
                    mint_quote,
                    referrer_token_account,
                    owner.as_ref(),
                ],
            )?;
        } else {
            invoke(
                &spl_token::instruction::transfer(
                    token_program_quote.pubkey(),
                    trader_token_account_quote.pubkey(),
                    referrer_token_account.pubkey(),
                    owner.pubkey(),
                    &[],
                    referrer_fee_atoms,
                )
                .map_err(manifest::validation::to_program_error)?,
                &[
                    token_program_quote,
                    trader_token_account_quote,
                    referrer_token_account,
                    owner.info,
                ],
            )?;
        }

        emit_stack(ReferrerFeeLog {
            market: *market.pubkey(),
            user: *owner.pubkey(),
            mint: *mint_quote.pubkey(),
            referrer_token_account: *referrer_token_account.pubkey(),
            referrer_fee: referrer_fee_atoms,
        })?;
    }

    // Sync to update the remaining balances post settlement.
    sync_fast(&wrapper_state, &market, market_info_index)?;

    // Updating after the authenticated transfers makes the accounting
    // invariant explicit: fee volume is cleared only after payment succeeds.
    let mut wrapper_data: RefMut<[u8]> = wrapper_state.info.try_borrow_mut()?;
    let mut wrapper: DynamicAccount<&mut ManifestWrapperUserFixed, &mut [u8]> =
        get_mut_dynamic_account(&mut wrapper_data);
    let market_info: &mut MarketInfo =
        get_mut_helper::<RBNode<MarketInfo>>(&mut wrapper.dynamic, market_info_index)
            .get_mut_value();
    market_info.quote_volume_unpaid = market_info
        .quote_volume_unpaid
        .saturating_sub(quote_volume_paid);

    Ok(())
}
