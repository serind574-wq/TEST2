use std::{mem::size_of, ops::Deref};

use crate::{
    market_info::MarketInfo, open_order::WrapperOpenOrder, wrapper_user::ManifestWrapperUserFixed,
};
use bytemuck::{Pod, Zeroable};
use hypertree::{
    get_helper, get_mut_helper, trace, DataIndex, FreeList, HyperTreeReadOperations,
    HyperTreeValueIteratorTrait, HyperTreeWriteOperations, RBNode, RedBlackTree,
    RedBlackTreeReadOnly, NIL,
};
use manifest::{
    program::{get_dynamic_account, invoke, invoke_passthrough_refs},
    quantities::BaseAtoms,
    require,
    state::{claimed_seat::ClaimedSeat, MarketFixed, RestingOrder},
    validation::{AccountViewExt, ManifestAccountInfo, Program, Signer},
};
use pinocchio::{
    account::{AccountView, Ref, RefMut},
    error::ProgramError,
    sysvars::{rent::Rent, Sysvar},
    ProgramResult,
};
use solana_program::pubkey::Pubkey;
use solana_system_interface::instruction as system_instruction;
use static_assertions::const_assert_eq;

pub const WRAPPER_BLOCK_PAYLOAD_SIZE: usize = 80;
pub const BLOCK_HEADER_SIZE: usize = 16;
pub const WRAPPER_BLOCK_SIZE: usize = WRAPPER_BLOCK_PAYLOAD_SIZE + BLOCK_HEADER_SIZE;

pub const EXPECTED_ORDER_BATCH_SIZE: usize = 16;

#[repr(C, packed)]
#[derive(Default, Copy, Clone, Pod, Zeroable)]
pub struct UnusedWrapperFreeListPadding {
    _padding: [u64; 11],
    _padding2: [u32; 1],
}
pub const FREE_LIST_HEADER_SIZE: usize = 4;
// Assert that the free list blocks take up the same size as regular blocks.
const_assert_eq!(
    size_of::<UnusedWrapperFreeListPadding>(),
    WRAPPER_BLOCK_SIZE - FREE_LIST_HEADER_SIZE
);
// Does not align to 8 bytes but not necessary
// const_assert_eq!(size_of::<UnusedWrapperFreeListPadding>() % 8, 0);

// Fee here is UI_WRAPPER_FEE_LAMPORTS, credited to the wrapper state. It
// lands there rather than on the collector directly because the collector is
// not one of the accounts any of these instructions already takes, and the
// point of charging here is to not change what callers have to pass. Collect
// sweeps it off later. Users who do not wish to pay this fee should use their
// own wrapper or interact directly with the manifest program.
pub(crate) fn collect_fee<'a>(
    payer: &Signer<'a>,
    wrapper_state: &WrapperStateAccountInfo<'a>,
) -> ProgramResult {
    // The system program's transfer, encoded directly. Building it through
    // `system_instruction::transfer` bincode encodes the instruction enum and
    // allocates a vector for the data and another for the account metas, and
    // this runs on every placement.
    let mut data: [u8; 12] = [0; 12];
    data[0] = 2;
    data[4..].copy_from_slice(&crate::UI_WRAPPER_FEE_LAMPORTS.to_le_bytes());
    invoke_passthrough_refs(
        &solana_sdk_ids::system_program::id(),
        &[payer.info, wrapper_state.info],
        &data,
    )?;

    Ok(())
}

pub(crate) fn expand_wrapper_if_needed<'a>(
    wrapper_state_account_info: &WrapperStateAccountInfo<'a>,
    payer: &Signer<'a>,
    system_program: &Program<'a>,
) -> ProgramResult {
    let need_expand: bool = does_need_expand(wrapper_state_account_info);
    if !need_expand {
        return Ok(());
    }

    {
        let wrapper_state: &AccountView = wrapper_state_account_info.info;

        let wrapper_data: Ref<[u8]> = wrapper_state.try_borrow()?;
        let new_size: usize = wrapper_data.len() + WRAPPER_BLOCK_SIZE;
        drop(wrapper_data);

        let rent: Rent = Rent::get()?;
        let new_minimum_balance: u64 = rent.try_minimum_balance(new_size)?;
        // Charge the rent the extra block costs, not the gap to the account's
        // current balance. The two were the same number until this account
        // started carrying fees: with a surplus sitting on it, funding up to
        // the new minimum spends that surplus on the user's own rent and the
        // fee is never collectible. The sibling wrapper prices expansion the
        // same way, for the same reason.
        let old_minimum_balance: u64 = rent.try_minimum_balance(wrapper_state.data_len())?;
        let lamports_diff: u64 = new_minimum_balance.saturating_sub(old_minimum_balance);

        invoke(
            &system_instruction::transfer(payer.pubkey(), wrapper_state.pubkey(), lamports_diff),
            &[payer.info, wrapper_state, system_program.info],
        )?;

        trace!(
            "expand_if_needed -> realloc {} {:?}",
            new_size,
            wrapper_state.pubkey()
        );
        #[cfg(feature = "fuzz")]
        {
            solana_program::program::invoke(
                &system_instruction::allocate(wrapper_state.pubkey(), new_size as u64),
                &[wrapper_state.clone(), system_program.info],
            )?;
        }
        #[cfg(not(feature = "fuzz"))]
        {
            wrapper_state.resize(new_size)?;
        }
    }

    let wrapper_state_info: &AccountView = wrapper_state_account_info.info;
    let wrapper_data: &mut [u8] = &mut wrapper_state_info.try_borrow_mut().unwrap();
    expand_wrapper(wrapper_data);

    Ok(())
}

pub fn expand_wrapper(wrapper_data: &mut [u8]) {
    let (fixed_data, dynamic_data) =
        wrapper_data.split_at_mut(size_of::<ManifestWrapperUserFixed>());

    let wrapper_fixed: &mut ManifestWrapperUserFixed = get_mut_helper(fixed_data, 0);
    let mut free_list: FreeList<UnusedWrapperFreeListPadding> =
        FreeList::new(dynamic_data, wrapper_fixed.free_list_head_index);

    free_list.add(wrapper_fixed.num_bytes_allocated);
    wrapper_fixed.num_bytes_allocated += WRAPPER_BLOCK_SIZE as u32;
    wrapper_fixed.free_list_head_index = free_list.get_head();
}

fn does_need_expand(wrapper_state: &WrapperStateAccountInfo) -> bool {
    let wrapper_data: Ref<[u8]> = wrapper_state.info.try_borrow().unwrap();
    let (fixed_data, _dynamic_data) = wrapper_data.split_at(size_of::<ManifestWrapperUserFixed>());

    let wrapper_fixed: &ManifestWrapperUserFixed = get_helper(fixed_data, 0);
    wrapper_fixed.free_list_head_index == NIL
}

pub(crate) fn check_signer(wrapper_state: &WrapperStateAccountInfo, owner_key: &Pubkey) {
    let mut wrapper_data: RefMut<[u8]> = wrapper_state.info.try_borrow_mut().unwrap();
    let (header_bytes, _wrapper_dynamic_data) =
        wrapper_data.split_at_mut(size_of::<ManifestWrapperUserFixed>());
    let header: &ManifestWrapperUserFixed =
        get_helper::<ManifestWrapperUserFixed>(header_bytes, 0_u32);
    assert_eq!(header.trader, *owner_key);
}

pub(crate) fn sync_fast(
    wrapper_state: &WrapperStateAccountInfo,
    market: &ManifestAccountInfo<MarketFixed>,
    market_info_index: DataIndex,
) -> ProgramResult {
    let market_data: Ref<[u8]> = market.try_borrow()?;
    let market_ref = get_dynamic_account::<MarketFixed>(&market_data);

    let mut wrapper_data: RefMut<[u8]> = wrapper_state.info.try_borrow_mut()?;
    let (fixed_data, wrapper_dynamic_data) =
        wrapper_data.split_at_mut(size_of::<ManifestWrapperUserFixed>());

    let market_info: &mut MarketInfo =
        get_mut_helper::<RBNode<MarketInfo>>(wrapper_dynamic_data, market_info_index)
            .get_mut_value();
    let trader = get_helper::<ManifestWrapperUserFixed>(fixed_data, 0).trader;
    market_info.trader_index = market_ref.resolve_trader_index(market_info.trader_index, &trader);
    let trader_index = market_info.trader_index;
    let mut orders_root_index: DataIndex = market_info.orders_root_index;

    if orders_root_index != NIL {
        let orders_tree: OpenOrdersTreeReadOnly =
            OpenOrdersTreeReadOnly::new(wrapper_dynamic_data, orders_root_index, NIL);

        // Cannot do this in one pass because we need the data borrowed for the
        // iterator so cannot also borrow it for updating the nodes.
        let mut to_remove_indices: Vec<DataIndex> = Vec::with_capacity(EXPECTED_ORDER_BATCH_SIZE);
        let mut to_update_and_core_indices: Vec<(DataIndex, DataIndex)> =
            Vec::with_capacity(EXPECTED_ORDER_BATCH_SIZE);
        for (order_index, order) in orders_tree.iter::<WrapperOpenOrder>() {
            let expected_sequence_number: u64 = order.get_order_sequence_number();
            let core_data_index = market_ref.resolve_order_index(
                order.get_market_data_index(),
                expected_sequence_number,
                trader_index,
                order.get_price(),
                order.get_is_bid(),
            );
            if core_data_index == NIL {
                to_remove_indices.push(order_index);
                continue;
            }
            // Verifies that it is not just zeroed and happens to match seq num,
            // also check that there are base atoms left.
            let core_resting_order: &RestingOrder =
                get_helper::<RBNode<RestingOrder>>(market_ref.dynamic, core_data_index).get_value();
            if core_resting_order.get_sequence_number() != expected_sequence_number
                || core_resting_order.get_num_base_atoms() == BaseAtoms::ZERO
            {
                to_remove_indices.push(order_index);
            } else {
                to_update_and_core_indices.push((order_index, core_data_index));
            }
        }
        // Update the amounts if there was partial fills.
        for (to_update_index, core_data_index) in to_update_and_core_indices.iter() {
            let node: &mut RBNode<WrapperOpenOrder> =
                get_mut_helper::<RBNode<WrapperOpenOrder>>(wrapper_dynamic_data, *to_update_index);
            let core_resting_order: &RestingOrder =
                get_helper::<RBNode<RestingOrder>>(market_ref.dynamic, *core_data_index)
                    .get_value();
            node.get_mut_value().set_market_data_index(*core_data_index);
            node.get_mut_value()
                .update_remaining(core_resting_order.get_num_base_atoms());

            // Needed because the way things are added could be off by 1 when
            // one of the orders fully matches as it is being placed. We only
            // know that the indices are right, not the actual orders there.
            node.get_mut_value()
                .set_price(core_resting_order.get_price());
            node.get_mut_value()
                .set_is_bid(core_resting_order.get_is_bid());
        }
        let mut orders_tree: RedBlackTree<WrapperOpenOrder> =
            RedBlackTree::<WrapperOpenOrder>::new(wrapper_dynamic_data, orders_root_index, NIL);
        for to_remove_index in to_remove_indices.iter() {
            orders_tree.remove_by_index(*to_remove_index);
        }
        orders_root_index = orders_tree.get_root_index();

        let wrapper_fixed: &mut ManifestWrapperUserFixed = get_mut_helper(fixed_data, 0);
        let mut free_list: FreeList<UnusedWrapperFreeListPadding> =
            FreeList::new(wrapper_dynamic_data, wrapper_fixed.free_list_head_index);
        for open_order_index in to_remove_indices.iter() {
            // Free the node in wrapper.
            free_list.add(*open_order_index);
        }
        wrapper_fixed.free_list_head_index = free_list.get_head();
    }
    let market_info: &mut MarketInfo =
        get_mut_helper::<RBNode<MarketInfo>>(wrapper_dynamic_data, market_info_index)
            .get_mut_value();
    market_info.orders_root_index = orders_root_index;

    // Sync balances
    let market_info: &mut MarketInfo =
        get_mut_helper::<RBNode<MarketInfo>>(wrapper_dynamic_data, market_info_index)
            .get_mut_value();
    let claimed_seat = if trader_index == NIL {
        ClaimedSeat::new_empty(trader)
    } else {
        *get_helper::<RBNode<ClaimedSeat>>(market_ref.dynamic, trader_index).get_value()
    };
    market_info.base_balance = claimed_seat.base_withdrawable_balance;
    market_info.quote_balance = claimed_seat.quote_withdrawable_balance;
    // A harvested/reclaimed seat starts its informational volume at zero.
    // Keep already accrued unpaid fees; do not wrap a reset into a huge fee.
    // Normal UI settlement collects payable fees while emptying the seat,
    // before defrag can harvest it. Activity bypassing settlement is not covered:
    // harvesting loses unsynced volume, and a reclaimed seat whose new volume
    // exceeds the cached baseline can hide the reset from this comparison.
    let quote_volume_difference = if claimed_seat.quote_volume < market_info.quote_volume {
        claimed_seat.quote_volume
    } else {
        claimed_seat
            .quote_volume
            .wrapping_sub(market_info.quote_volume)
    };
    market_info.quote_volume_unpaid = market_info
        .quote_volume_unpaid
        .saturating_add(quote_volume_difference);
    market_info.quote_volume = claimed_seat.quote_volume;
    market_info.last_updated_slot = pinocchio::sysvars::clock::Clock::get().unwrap().slot as u32;

    Ok(())
}

pub(crate) fn get_market_info_index_for_market(
    wrapper_state: &WrapperStateAccountInfo,
    market: &Pubkey,
) -> DataIndex {
    let mut wrapper_data: RefMut<[u8]> = wrapper_state.info.try_borrow_mut().unwrap();
    let (fixed_data, wrapper_dynamic_data) =
        wrapper_data.split_at_mut(size_of::<ManifestWrapperUserFixed>());

    let wrapper_fixed: &ManifestWrapperUserFixed = get_helper(fixed_data, 0);
    let market_infos_tree: MarketInfosTree = MarketInfosTree::new(
        wrapper_dynamic_data,
        wrapper_fixed.market_infos_root_index,
        NIL,
    );

    // Just need to lookup by market key so the rest doesnt matter.
    let market_info_index: DataIndex =
        market_infos_tree.lookup_index(&MarketInfo::new_empty(*market, NIL));
    market_info_index
}

/// Validation for wrapper account
#[derive(Clone)]
pub struct WrapperStateAccountInfo<'a> {
    pub(crate) info: &'a AccountView,
}
pub type MarketInfosTree<'a> = RedBlackTree<'a, MarketInfo>;
pub type MarketInfosTreeReadOnly<'a> = RedBlackTreeReadOnly<'a, MarketInfo>;
pub type OpenOrdersTree<'a> = RedBlackTree<'a, WrapperOpenOrder>;
pub type OpenOrdersTreeReadOnly<'a> = RedBlackTreeReadOnly<'a, WrapperOpenOrder>;

pub const WRAPPER_USER_DISCRIMINANT: u64 = 1;

impl<'a> WrapperStateAccountInfo<'a> {
    #[inline(always)]
    fn _new_unchecked(info: &'a AccountView) -> Result<WrapperStateAccountInfo<'a>, ProgramError> {
        require!(
            info.owner_pubkey() == crate::ID,
            ProgramError::IllegalOwner,
            "Wrapper must be owned by the program",
        )?;
        Ok(Self { info })
    }

    pub fn new(info: &'a AccountView) -> Result<WrapperStateAccountInfo<'a>, ProgramError> {
        let wrapper_state: WrapperStateAccountInfo<'a> = Self::_new_unchecked(info)?;

        let market_bytes: Ref<[u8]> = info.try_borrow()?;
        let (header_bytes, _) = market_bytes.split_at(size_of::<ManifestWrapperUserFixed>());
        let header: &ManifestWrapperUserFixed =
            get_helper::<ManifestWrapperUserFixed>(header_bytes, 0_u32);

        require!(
            header.discriminant == WRAPPER_USER_DISCRIMINANT,
            ProgramError::InvalidAccountData,
            "Invalid wrapper state discriminant",
        )?;

        Ok(wrapper_state)
    }

    pub fn new_init(info: &'a AccountView) -> Result<WrapperStateAccountInfo<'a>, ProgramError> {
        require!(
            info.is_signer(),
            ProgramError::MissingRequiredSignature,
            "Wrapper state must sign initialization",
        )?;
        let market_bytes: Ref<[u8]> = info.try_borrow()?;
        let (header_bytes, _) = market_bytes.split_at(size_of::<ManifestWrapperUserFixed>());
        let header: &ManifestWrapperUserFixed =
            get_helper::<ManifestWrapperUserFixed>(header_bytes, 0_u32);
        require!(
            info.owner_pubkey() == crate::ID,
            ProgramError::IllegalOwner,
            "Market must be owned by the Manifest program",
        )?;
        // On initialization, the discriminant is not set yet.
        require!(
            header.discriminant == 0,
            ProgramError::InvalidAccountData,
            "Expected uninitialized market with discriminant 0",
        )?;
        Ok(Self { info })
    }
}

impl<'a> Deref for WrapperStateAccountInfo<'a> {
    type Target = AccountView;

    fn deref(&self) -> &Self::Target {
        self.info
    }
}
