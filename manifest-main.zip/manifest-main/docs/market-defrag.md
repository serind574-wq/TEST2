# Collector-only market defragmentation

`Defrag` (core opcode 14) atomically harvests empty seats, compacts market nodes,
retains two spare nodes, resizes the account, and returns released/excess lamports
to the collector. It also withdraws excess lamports from non-native Token-2022
vaults. Classic-token vault excess is retained until closure. When no funded
seats or orders remain **and both vaults are empty and
closable**, it closes the vaults and market instead.

Production authority is `B6dmr2UAn2wgjdm3T4N1Vjd8oPYRRTguByW7AEngkeL6`, the same
hardcoded collector as the wrapper. The `test` feature substitutes the existing
test collector. Never deploy a build with `test` enabled.

## Instruction and invariants

The instruction takes an optional little endian `u32` after the discriminator:
the number of nodes this run may relocate, with zero or an absent value meaning
unbounded. See [Bounded runs](#bounded-runs). Accounts, in order:

| Account | Access |
| --- | --- |
| Collector | Writable signer; receives refunds and funds any temporary growth |
| Market | Writable |
| Base vault | Writable, validated against the market and mint |
| Quote vault | Writable, validated against the market and mint |
| Base token program | Readonly |
| Quote token program | Readonly |
| System program | Readonly |

A seat survives if either withdrawable balance is nonzero or any resting order
references it, including global, reverse and expired-but-not-yet-removed orders.
Seats with zero balances and no orders are harvested; their historical per-seat
volume disappears. Market lifetime volume is preserved.

Compaction relocates the existing order nodes and rewrites their links and owner
indices without changing tree shape. Ordinary remove/reinsert at equal prices
would change FIFO priority. Surviving seats are inserted into a rebuilt seat tree;
reclaimed seats are simply left out of it, so reclaiming costs no tree work and a
run that drops thousands of seats costs no more than one that drops none.
Order sequence IDs, prices, quantities, expiry, type, reverse spread and global gas
prepayments are unchanged. The next-order sequence counter advances once to
invalidate wrapper quiet-sync caches; gaps in sequence numbers are valid.

A market larger than `MAX_DEFRAG_BLOCKS` (65,536 nodes, a 5.2 MB account) is
rejected with `InvalidAccountData`. The live bitmap is one bit per block, so that
bound caps it at 8 KiB of the 32 KiB heap. The moved-seat mapping is pre-allocated
to `MAX_MOVED_SEATS_PER_RUN` (1,024 relocated seats, 8 KiB) and never grows, so a
run cannot exhaust the heap; a run that fills it stops relocating like an
exhausted budget and the next run continues. Neither bound caps the compute cost
of rebuilding the surviving seat tree.

The live account target is `256 + 80 * (surviving seats + orders + 2)` bytes.
Two spare nodes preserve capacity for paths that need two allocations, including
reverse-order handling. Core batches containing placements add **at most one**
extra spare node toward a target of five, in addition to individual allocations
needed to place the orders. They do not shrink larger free lists. The batch payer
supplies this rent; cancel-only and empty batches never expand. Defrag reduces the
reserve back to two, or closes the account.

The fixed header and its padding stay unchanged at 256 bytes. No free-node count
is stored or maintained. Reserve checks use the existing free list, stopping once
they have found the required number of nodes (five for a core batch update).

Excess-lamport withdrawal is restricted to Token-2022. The deployed classic
Tokenkeg program does not support this instruction, even though ProgramTest's
bundled p-token replacement does. Classic vault excess is left untouched while
the market stays open and is recovered through normal account closure when
eligible. See the [classic-token processor](https://github.com/solana-program/token/blob/main/program/src/processor.rs).

Native/WSOL vaults are skipped while the market stays open: principal, recorded
native rent reserve and unsynchronized deposits remain untouched. Closure requires
zero token amounts and zero withheld transfer fees. Unknown/confidential token
extensions prevent automatic closure. Supported vault extensions are transfer-fee
amount, transfer-hook account, pausable account and immutable owner. Token CPIs
run before direct market-lamport changes; any failure rolls back the instruction.

## Bounded runs

Passing a relocation budget makes a single market compactable across several
transactions. Each run:

- reclaims every eligible seat, which is free, and relocates at most `limit`
  surviving nodes into the holes beneath them, working from the top of the
  account down because only vacating a high block lets it shrink;
- leaves the market fully consistent — trees valid, balances intact, FIFO
  preserved, at least two spare nodes — and never larger than it started;
- converges: repeating until the size stops changing reaches the same layout a
  single unbounded run would produce.

So an operator who cannot fit a market in one transaction picks a budget,
simulates it against current state, and repeats until the size settles. There is
no resume cursor and no partial state to carry between runs; each one recomputes
everything from the account.

What a budget cannot bound is the single pass over allocated blocks and the seat
tree rebuild over the survivors, which is why `MAX_DEFRAG_BLOCKS` exists. Model
both terms when choosing a budget rather than assuming a small `limit` makes any
market affordable. The rebuild term is the per-run floor: measured on SBPF v3,
a 2,202-block market with 1,100 surviving seats costs about 750,000 CU per run,
a 6,402-block market with 1,400 survivors about 1,330,000 CU, and a run over
2,500 survivors exceeds the 1.4M ceiling, so a market with more than roughly
two thousand surviving seats cannot run Defrag at all. No live market is near
that; the failure is a clean compute-meter stop, not a memory fault.

The moved-seat mapping records an eight-byte pair per relocated seat. It is
pre-allocated to `min(limit, MAX_MOVED_SEATS_PER_RUN)` entries and never grows,
because growing a vector strands its old allocation in the SBF bump allocator.
A run that would relocate more than 1,024 seats stops when the mapping fills,
exactly as if the budget had run out, so even a zero-`limit` run cannot exhaust
the heap and repeating still converges. Compute, not heap, is what an operator
sizes a budget for.

`ManifestClient.defragIx(collector, limit?)` and the Rust `defrag_instruction`
builder both take the budget as an optional argument.

## Wrapper compatibility and rollout

Both wrappers resolve cached seats by trader public key and orders by sequence ID
plus owner. Offsets are checked for bounds, alignment and node type. A stale order
hint searches its side and price level, including all equal-price entries after
tree rotations. Ordinary fills and cancels do not scan both books. Updated hints
are stored in the wrapper.

The regular wrapper recreates missing seats before batch updates. Deposit keeps
its original instruction and account list. Callers must claim a seat before an
initial deposit and claim it again after harvesting; ClaimSeat and Deposit can
be composed in the same transaction. ClaimSeat also refreshes moved seat/order
hints and repairs an existing MarketInfo instead of inserting a duplicate.
The SDK's `getSetupIxs` and `getClientForMarket` check the live core seat and its
index, returning or sending ClaimSeat when the seat was harvested or moved.
Callers can compose those setup instructions with Deposit in the same transaction.
Zero withdrawals after harvesting are harmless. The UI wrapper refreshes before
cancellation, recreates seats through its existing placement path, and prepays
placement capacity from its designated payer (one order plus five spare nodes).
Normal UI settlement withdraws balances and collects payable fees atomically,
before the empty seat becomes eligible for harvesting. Defrag assumes that
settlement flow. Core activity that bypasses UI settlement is not covered:
harvesting can lose unsynced fee volume, and a recreated seat whose new volume
exceeds the previous baseline can hide the reset. While the market remains open,
the wrapper can settle already accrued fees with no core seat; closing the market
prevents any remaining settlement. These assumptions are documented in the UI
wrapper.

Upgrade **both wrappers before invoking Defrag**. Direct core clients must reload
market state and refresh index hints after maintenance; old strict hints can fail.
Use `ManifestClient.defragIx(collector, limit?)` or the Rust `defrag_instruction`
builder. Large accounts need an explicit compute budget, up to 1.4 million units;
simulate each transaction against current state before sending. A market that
does not fit in one transaction is compacted with a relocation budget over
several, subject to `MAX_DEFRAG_BLOCKS`. Closure is irreversible; closed market
addresses are no longer valid trading accounts.

No deployment or mainnet maintenance transaction is part of this change.

## Snapshot estimate for this implementation

Based on the saved September 29, 2026 census at core slot 451678322 and its vault
reads, using the observed 5,080 lamports/byte rent schedule. This is an estimate,
not a simulation of every market, and excludes transaction fees and all globals.

| Included component | SOL |
| --- | ---: |
| Market compaction, seat harvesting, excess rent and empty-market closure, net of growth | 29.440501137 |
| Non-native Token-2022 **market** vault excess | 7.504808471 |
| Remaining vault lamports when retiring 1,324 empty markets, including classic excess | 5.236767012 |
| **Total** | **42.182076620** |

This corrects an important difference from the earlier scenario tables: retaining
exactly two spare nodes sometimes requires growth. The net market figure includes
0.481584 SOL of additional retained rent on markets previously too small for two
spares. Temporary expansion before compaction is returned when no longer needed.
Vault excess and closure amounts are not double-counted. Global vaults are excluded.
The prior 43.402998014 SOL estimate included 1.220921394 SOL of excess in open
classic-token market vaults that this implementation cannot withdraw. Classic
excess recovered on retirement is included in the closure row instead.

## Non-global savings left out

- **1.220921394 SOL** of excess lamports in classic-token market vaults that stay
  open. Deployed Tokenkeg cannot withdraw that excess; eligible closure remains
  supported and is already counted above.
- **0.208584356 SOL** of recorded native rent reserve above current rent in market
  vaults that remain open. Recovering it needs a separate, validated WSOL vault
  migration/reinitialization design preserving backing.
- **0.027649032 SOL** of unsynchronized native lamports in those remaining vaults.
  These are excluded because their economic ownership needs a separate policy.
- Wrapper-account compaction, shrinking or closure, and wrapper excess-rent
  collection are separate maintenance work; this instruction does not receive
  wrapper accounts. No additional amount was assessed here.
- Token-vault byte-size reductions: this instruction collects rent using each
  vault's existing length. Removing extensions or rebuilding smaller token accounts
  is separate work; additional savings are unquantified.
- Vault/market retirement blocked by token dust, withheld fees or unsupported
  extensions. This implementation does not sweep tokens or remove extensions;
  those balances may carry claims beyond rent. Additional savings are unquantified.

See [the broader census](assessments/mainnet-rent/EXPANDED.md) for input data and the
separate global analysis.

## Validation

### Certora coverage

`programs/manifest/src/certora/confs/rules-defrag.conf` runs the defrag rules
from the normal unified `certora` build (no defrag-specific feature). It
compiles the real defrag processor and account compactor; the compactor uses
the real red-black tree, not the fixed-index seat/order mocks used by matching
proofs. Defrag preservation is stated by trader pubkey and order sequence
number because a byte index can move or be reused after an empty seat is
reclaimed.

The verification `require!` stays an assumption, as the other rules were
proven: returning real errors from every call site fails the prover's memory
analysis with unknown-provenance errors across the legacy suite. Defrag's own
validation — and `Signer::new_payer_rejecting`, used only by its processor —
opts back into production branches with `require_rejecting!`, whose production
expansion is identical, so the rejection rules observe the exact error codes.
On top of the shared base configuration, `rules-defrag.conf` enables
`assert_on_panic` (panics fail these rules instead of pruning), exact bitwise
semantics and a deeper loop bound.

The whole-pass harness contains eight blocks, three seats and three orders with
symbolic placements, keys, balances, amounts, resting order types, and
relocation budgets. The market bytes live in the prover's pinned input region
(`account_views_with_mem_layout!`), like every verified rule's accounts, and
the before-image lives in stack copies of the inserted values: the memory
model havocks heap-to-heap snapshots, so there is no clone. Two orders share
a price on one side; the third is on the other side.
Both side assignments are checked. It asserts:

- successful completion, unchanged surviving seat payloads, and reclamation only
  of seats with neither withdrawable funds nor orders;
- unchanged order payloads after translating the owner index, including global
  and reverse order metadata;
- the same order-tree links, colors, roots and best nodes under the relocation
  map, preserving price/FIFO priority;
- unchanged fixed metadata/funds ghosts except allocation indices and the
  checked sequence-number increment;
- a complete, zeroed, acyclic free list with at least two spare blocks, a size
  that never grows, and respect for the relocation budget;
- preservation after a budget-one pass, truncation, and a second pass, plus
  explicit zero-budget, empty-market and sequence-overflow cases.

Separate rules check bitmap updates, individual seat/order relocation (including
root, parent and child repair), malformed allocation/owner rejection, and the
actual instruction dispatch's collector, signer, writability and data checks.
`optimistic_loop` is false, so insufficient loop unwinding fails verification.
The shared base configuration keeps the optimistic memory assumptions the rest
of the suite was proven under (the prover's translation aborts without them);
this configuration adds exact bitwise operations on top. The authorization
harness takes its wallet account from the canonical pinned input region with
symbolic keys, flags and lamports; these rejection paths never access its data.

These are **bounded whole-pass obligations**, not a proof for every market up to
65,536 blocks. They do not prove the 1,024-moved-seat cap or an arbitrary number
of repeated passes. Prices retain the existing Certora single-limb abstraction;
the production global-address cache is replaced by the existing funds ghosts.
Successful processor paths involving expansion, token CPIs, rent refunds and
account/vault closure are not covered by these rules. The existing SBF tests
below cover those behaviors. Do not infer global gas-deposit/CPI conservation
from unchanged order metadata alone.

**Proof status (2026-10-14).** The instruction-data rejection, writable-
collector rejection and bitmap-preservation rules verify remotely, including
their explicit non-vacuity checks, and are what `rules-defrag.conf` gates on.
Every other defrag rule is blocked by the prover, not refuted, and is listed in
the configuration as an exclusion naming its blocker:

- Slicing any rule that inlines the shared whole-pass market builder crashes
  the prover itself (`IllegalStateException: Unexpected setRegister on
  bottom`, reproduced on single-rule jobs). Two global-order no-revert rules
  crash the same way.
- The relocate rules report a slice-bounds panic on indices that are in bounds
  by construction, and the collector/signature rules report the account header
  reading back differently inside the program than in the rule's own
  assumption — memory-model imprecision, with concretely impossible witnesses.
- The invalid-allocation rule exceeds practical solve time.

The same backend limits break many **pre-existing** rules, on main's unchanged
code as well (verified by running origin/main through the identical pipeline).
None of this had been visible: the previous workflow submitted with
`--wait_for_results none` and the prover could not even disassemble the
unprepared sbpf-v3 ELF, so no proof had actually run since the v3 migration.
Those exclusions are inline in their configurations.

The largest group is every rule that loads a processor account context
(deposit, withdraw, batch update, claim/release seat, market state, global
tokens): they fail memory-analysis encoding with error 3006, an escaping stack
pointer. That was bisected to `ManifestAccountInfo::<T>::new`, with one
single-rule prover job per candidate. Each construct inside it verifies on its
own — the owner check, the borrow guard, `get_helper`'s cast, reading the
header by value, and `verify_discriminant` on a stack copy — as do
`Signer::new` and `TokenAccountInfo::new_with_owner`, and so does the entire
rule harness without the loader. Only the whole function fails, so there is no
local idiom to rewrite. The prover's own log gives the reason: its mod-ref
analysis bails out on these regions ("contains 37 blocks, exceeding the
maximum supported size of 8"), after which it answers every aliasing query
conservatively and a legitimate stack store looks like an escape. That bound
is hardcoded as `maxRegionSize = 8UL` in the prover
(`src/main/kotlin/sbf/cfg/PromoteMemcpy/MemcpyPatternRewriter.kt`), not
exposed as an option. `-solanaMaxSilencedPTAErrors` does get past the
encoding failure, but it inserts an assertion at the error site, and that site
is reachable on these rules' own paths, so they become unprovable rather than
proven. Raising the limit needs a prover change; these rules cannot be
recovered from this repository.

Most hypertree rules report counterexamples whose symbolic tree state is
havocked. Rebuilding their node writes field by field, the change that fixed
the defrag bitmap rule, does not help them.

Run from `programs/manifest/src/certora/confs`:

```sh
certoraSolanaProver rules-defrag.conf --compilation_steps_only
certoraSolanaProver rules-defrag.conf --wait_for_results all
```

CI compiles every configuration on PRs. On main pushes or a manual workflow
run, the defrag rules run as their own `rules-defrag.conf` matrix entry in the
same unified `certora` build (no defrag-specific feature or workflow input).
Each matrix entry waits for actual proof results and fails on violations or
errors. Batched vacuity sub-rules are disabled (`rule_sanity: none`): they
starve into SANITY_FAILED in multi-rule jobs or hit encoding errors of their
own, so they cannot gate; the defrag rules carry explicit satisfy checks
instead.

The proof build retains v3 call relocations and names static syscalls for
Certora's disassembler, which otherwise mistakes their numeric identifiers for
relative function addresses, and restores the classic `__rust_alloc` family
names that platform-tools v1.53 mangles, so the prover's allocator
interception keeps working. `certora/prepare_elf.py` changes only non-loaded
symbol/relocation tables and checks that every loaded byte is unchanged.
Unknown syscalls fail preparation. Production builds do not use this
preparation step.

### Runtime validation

- SBF builds for core, regular wrapper and UI wrapper using the pinned v1.57 tools.
- All 153 core, 40 regular-wrapper and 12 UI-wrapper SBF integration tests passed.
- The classic-token compatibility correction also passes all eight defrag SBF
  integration cases, including excess preservation and collection on closure.
- Core integration coverage includes collector authorization/empty closure,
  balance and FIFO preservation/gradual reserve replenishment, classic-token
  excess preservation and collection on closure, Token-2022 excess collection,
  WSOL preservation, 13,000 seats with 1,000 funded
  survivors, and an account containing 13,002 free nodes.
- The large seat-population case (13,000 seats, 1,000 funded survivors) asserts
  consumption stays under 1,250,000 CU against the 1.4M ceiling, preserving
  execution headroom as relocation and validation change.
- Reserve regressions check one-node replenishment toward five, no expansion for
  cancel-only or empty batches, and cancellation after defrag by an owner with
  no SOL. Wrapper coverage includes moved-order cancellation and harvested-seat
  recovery. Existing tests cover ordinary matching, reverse orders and gas refunds.
- All 94 core library tests passed, including rejection of an order that is
  missing from its parent's child links during relocation.
- Core library tests cover the bounded path directly: that budget-one runs
  converge byte for byte on the unbounded layout, that no bounded run grows the
  account or invalidates intermediate state, that the hardcoded node offsets
  match the typed accessors, and that an oversized market is rejected.
- TypeScript typecheck, lint and formatting passed; 22 focused SDK tests passed,
  including nine setup regressions for harvested/moved seats, reused old indices,
  unchanged seats and clients without a private key.
- All 12 slim Rust-client parsing, instruction and SBF integration tests passed.
